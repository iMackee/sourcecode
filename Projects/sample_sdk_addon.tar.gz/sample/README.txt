To build the add-on:
	make -j8 PRODUCT-sample_addon-sdk_addon
   