//
//  DatePickerController.h
//  GalleryCalendar_iPad
//
//  Created by 何 勇 on 11-11-19.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DatePickerDelegate

@optional
- (void)onPickedDate: (NSDate *)date;
- (void)onClickedFinish;

@end


@interface DatePickerController : UIViewController {
    NSDate *pickedDate;
    id<DatePickerDelegate> _delegate;
}
@property (retain, nonatomic) NSDate *pickedDate;
@property (retain, nonatomic) id<DatePickerDelegate> delegate;
@property (retain, nonatomic) IBOutlet UIDatePicker *datePicker;

- (IBAction)setToday:(id)sender;
- (IBAction)pickFinish:(id)sender;
- (IBAction)datePickerSelected:(id)sender;
@end
