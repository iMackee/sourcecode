//
//  ViewController.m
//  InstaCalendar
//
//  Created by 何 勇 on 11-11-25.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import "CalendarImageView.h"
#import "MergeImageViewController.h"
#import "PreviewOneMonthView.h"

@interface ViewController (private)

//- (void) updatePickDateButtonTitle: (NSDate *)date;
- (void) setupNewPopoverControllerForViewController:(UIViewController *)vc;
- (void)handleDismissedPopoverController:(UIPopoverController*)popoverController;

@end

@implementation ViewController

@synthesize datePicker;
@synthesize mainImageView;
//@synthesize segmentedControl;
//@synthesize chooseDateButton;
//@synthesize chooseDateButton;
@synthesize chosenDate; //, chosenCalendar;
@synthesize chosenImage;
@synthesize imagePicker = _imagePicker;  // Custom GridView image picker
@synthesize datePickerActionSheet;
@synthesize pickedImages = _pickedImages;
@synthesize calendarImageView = _calendarImageView;
@synthesize currentPopover;

#define ACTION_SHEET_TITLE_CHOOSE @"Choose Image Source"
#define ACTION_SHEET_TITLE_SHARE  @"Share"

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // methods
//    [self updatePickDateButtonTitle:[NSDate date]];
    [self redrawCalendarImageView:chosenDate];
    _myAssetsLibraryAccessor = [[MyAssetsLibraryAccessor alloc] init];
}


#pragma mark - UIRotationGestureRecognizer
//rotate the calendar image view
- (void)calendarRotated:(UIRotationGestureRecognizer *)recognizer
{
    CGAffineTransform trans = CGAffineTransformMakeRotation(recognizer.rotation);
    self.calendarImageView.transform =  trans;
}

#pragma mark - UIPanGestureRecognizer
//move the calendar image view
- (void)calendarMoved:(UIPanGestureRecognizer *)recognizer
{
    //NSLog(@"calendar image moved");
    if ((recognizer.state == UIGestureRecognizerStateChanged) || (recognizer.state == UIGestureRecognizerStateEnded)) {	
        // get the distance moved
        CGPoint movedTo = [recognizer translationInView:self.view];
        // get the original center
        CGPoint center = self.calendarImageView.center;
        // compute new center
        center.x = center.x + movedTo.x;
        center.y = center.y + movedTo.y;
        // set new center to move image
        self.calendarImageView.center = center;
        // reset transition
        [recognizer setTranslation:CGPointZero inView:self.view];
    }
}


// button "Choose Date"
//- (IBAction)pickDate:(id)sender {
//    //    [self showDatePickerView];  // for iPhone
//    // for iPad
//    NSLog(@"showDatePickerView");
//    //    if (self.currentPopover) {
//    //        [self.currentPopover dismissPopoverAnimated:YES];
//    //        self.currentPopover = nil;
//    //        return;
//    //    }
//    DatePickerController *dpc = [[[DatePickerController alloc] initWithNibName:nil bundle:nil] autorelease];
//    [dpc setDelegate:self];
//    [self setupNewPopoverControllerForViewController:dpc];
//    //    self.currentPopover = [[[UIPopoverController alloc] initWithContentViewController:dpc] autorelease];
//    //    self.currentPopover.delegate = self;
//    self.currentPopover.popoverContentSize = dpc.view.frame.size;
//    [self.currentPopover presentPopoverFromBarButtonItem:sender permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
//}


// button "Start"
- (IBAction)startMerge:(id)sender {
    //    [self chooseImageOption];
    NSLog(@"Show grid view");
    
    /* can only use GridImagePickerView or GridImagePickerConroller */
    
    // show all the images' thumbnail in one scroll view.
    GridImagePickerView *gridView = [[GridImagePickerView alloc] init];
    [gridView setDelegate:self];
    
    // TODO: show images with albums, under testing, display problems in iOS 5
    //    GridImagePickerController *gridView = [[GridImagePickerController alloc] init];
    if (self.chosenDate) {
        [gridView setChosenDate:self.chosenDate];
    } else {
        [gridView setChosenDate:[NSDate date]];                    
    }
    
    gridView.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController:gridView animated:YES];
    [gridView release];
}

- (IBAction)singleMerge:(id)sender {
    PreviewOneMonthView *view = [[PreviewOneMonthView alloc] init];
    view.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController:view animated:YES];
    [view release];
}


// pop over view

//- (void)setupNewPopoverControllerForViewController:(UIViewController *)vc {
//    if (self.currentPopover) {
//        [self.currentPopover dismissPopoverAnimated:YES];
//        [self handleDismissedPopoverController:self.currentPopover];
//    }
//    self.currentPopover = [[[UIPopoverController alloc] initWithContentViewController:vc] autorelease];
//    self.currentPopover.delegate = self;
//}
//
//
//- (void)handleDismissedPopoverController:(UIPopoverController*)popoverController {
//    if ([popoverController.contentViewController isMemberOfClass:[DatePickerController class]]) {
//        NSLog(@"dismissed date picker view");
//        DatePickerController *dpc = (DatePickerController *)popoverController.contentViewController;
//        //NSLog(@"dpc: %@", dpc);
//        self.chosenDate = [dpc.datePicker date];
//        //NSLog(@"self.chosenDate: %@",self.chosenDate);
//        
//        [self updatePickDateButtonTitle:chosenDate];
//        // regenerate the calendar view
//        [self redrawCalendarImageView:chosenDate];
//    }
//    self.currentPopover = nil;
//}


//#pragma mark - Popover controller delegate
//- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
//    [self handleDismissedPopoverController:popoverController];
//}


//#pragma mark - DatePickerDelegate
//- (void)onClickedFinish
//{
//    [self.currentPopover dismissPopoverAnimated:YES];
//    [self handleDismissedPopoverController:self.currentPopover];
//}
//
//// on date picked
//- (void)onPickedDate:(NSDate *)date
//{
//    NSLog(@"onPickedDate: %@", date);
//    self.chosenDate = date;
//    [self updatePickDateButtonTitle:chosenDate];
//    // regenerate the calendar view
//    [self redrawCalendarImageView:chosenDate];
//}


//- (void) updatePickDateButtonTitle: (NSDate *)date
//{
//    NSDateComponents *comp = [[NSCalendar currentCalendar] components: NSMonthCalendarUnit | NSYearCalendarUnit fromDate: date];
//    NSInteger month = [comp month];
//    NSInteger year = [comp year];
//    NSString *s = [NSString stringWithFormat:@"%d - %d", year, month];
//    //    [self.chooseDateButton setTitle:s forState:UIControlStateNormal];
//    self.chooseDateButton.title = s;
//}


// draw the calendar image view according to the chosen calendar
- (void)redrawCalendarImageView: (NSDate *)date
{
    if (self.calendarImageView) {
        [self.calendarImageView removeFromSuperview]; // remove the old one
    }
    // generate a calendar
    //    self.calendarImageView = [[[CalendarImageView alloc] init] makeCalendar:date];
    self.calendarImageView = [CalendarImageView makeCalendar:date];
    [self.view addSubview:self.calendarImageView];
    
    // add a rotation gesture recognizer
    UIRotationGestureRecognizer *rotationGesture = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(calendarRotated:)];  
    [self.view addGestureRecognizer:rotationGesture];  
    [rotationGesture release];  
    
    // add a move gesture recognizer
    self.calendarImageView.userInteractionEnabled = YES;
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(calendarMoved:)];
    [self.calendarImageView addGestureRecognizer:panGesture];
    [panGesture release];
}



// show an alert view
- (void) showAlertWithTitle:(NSString *)title withMessage:(NSString *)msg withButton:(NSString *)btn
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:msg delegate:nil cancelButtonTitle:btn otherButtonTitles: nil];
    [alert show];	
    [alert release];
}


#pragma mark UIImagePickerController Delegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)info {
    //NSLog(@"OS Version: %@", [[UIDevice currentDevice] systemVersion]);
//    NSLog(@"in imagePickerController:didFinishPickingImage:editingInfo");
	self.chosenImage = image;
	[self.mainImageView setImage:chosenImage];
    
    if (self.pickedImages) {
        [self.pickedImages removeAllObjects];
    }
    self.pickedImages = [NSMutableArray arrayWithObject:image];
	[self dismissModalViewControllerAnimated:YES];    
}



#pragma mark - GridImagePickerDelegate realization
- (void) onPickedImagesURLs:(NSMutableArray *)imagesURLs
{
    //NSLog(@"You have picked: %d", [images count]);
    self.pickedImages = imagesURLs;
}



#pragma mark - memory release
- (void)viewDidUnload
{
    [self setMainImageView:nil];
    [self setDatePicker:nil];
    [self setDatePickerActionSheet:nil];
    [self setPickedImages:nil];
    [self setCalendarImageView:nil];
//    [self setChooseDateButton:nil];
//    [self setChooseDateButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [datePicker release];
    [mainImageView release];
    [chosenDate release];
    [datePickerActionSheet release];
    [calendarMainText release];
//    [chooseDateButton release];
//    [chooseDateButton release];
    [super dealloc];
}

@end
