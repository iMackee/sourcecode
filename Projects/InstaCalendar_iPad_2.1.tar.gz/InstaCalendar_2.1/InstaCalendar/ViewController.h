//
//  ViewController.h
//  InstaCalendar
//
//  Created by 何 勇 on 11-11-25.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "MergeDetailViewController.h"
#import "MyAssetsLibraryAccessor.h"
#import <CoreGraphics/CoreGraphics.h>
#import "GridImagePickerView.h"
//#import "DatePickerController.h"
//#import "GridImagePickerController.h"  // under testing, display problems in iOS 5

@interface ViewController : UIViewController  <UINavigationControllerDelegate, UIImagePickerControllerDelegate, GridImagePickerDelegate, UIPopoverControllerDelegate>
{
//    UIBarButtonItem *chooseDateButton;
    UIDatePicker *datePicker;
    NSDate *chosenDate;
    UIActionSheet *datePickerActionSheet;
    
    UIImage* chosenImage;
    UIImageView *mainImageView;
    
    GridImagePickerView *_imagePicker;
    
    NSMutableArray *_pickedImages;
    UILabel *calendarMainText;
    UIImageView *_calendarImageView;
    
    MyAssetsLibraryAccessor *_myAssetsLibraryAccessor;
    
    UIPopoverController *currentPopover;
}

@property (nonatomic, retain) UIDatePicker *datePicker;
@property (nonatomic, retain) UIActionSheet *datePickerActionSheet;
@property (nonatomic, retain) NSDate *chosenDate;         // keep chosen date
@property (nonatomic, retain) UIImage* chosenImage;         // keep one image
@property (nonatomic, retain) NSMutableArray *pickedImages; // keep picked multiple images
@property (nonatomic, retain) UIImageView *calendarImageView; // calendar view

@property (nonatomic, retain) UIPopoverController *currentPopover;

@property (nonatomic, retain) GridImagePickerView *imagePicker;
@property (nonatomic, retain) IBOutlet UIImageView *mainImageView;
//@property (nonatomic, retain) IBOutlet UIBarButtonItem *chooseDateButton;

//- (IBAction)pickDate:(id)sender;
- (IBAction)startMerge:(id)sender;
- (IBAction)singleMerge:(id)sender;
- (void)redrawCalendarImageView: (NSDate *)date;
- (void)showAlertWithTitle: (NSString *)title withMessage: (NSString *)msg withButton: (NSString *)btn;
//- (void)showDatePickerView;

@end
