//
//  CalendarImageView.h
//  GalleryCalendar
//
//  Created by User on 11/11/05.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>  // for .layer property of a view

int _increment;

@interface CalendarImageView : UIImageView

+ (UIImageView *)makeCalendar: (NSDate *) calendar;

+ (UIView *)makeCalendarWithYear: (NSInteger) year andMonth: (NSInteger) month;

+ (UIView *)changeCalendarColorWithYear: (NSInteger) year andMonth: (NSInteger) month;

@end
