//
//  MyAssetsLibraryAccessor.m
//  GalleryCalendar
//
//  Created by User on 11/11/14.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyAssetsLibraryAccessor.h"

@implementation MyAssetsLibraryAccessor

@synthesize delegate=_delegate;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        _assetsLibrary = [[ALAssetsLibrary alloc] init];
    }
    
    return self;
}


//+ (void)addObserverForAssetsLibraryChange:(id)anObserver
//                                 selector:(SEL)aSelector {
//    NSNotificationCenter *defaultCenter = [NSNotificationCenter defaultCenter];
//    [defaultCenter addObserver:anObserver
//                      selector:aSelector
//                          name:ALAssetsLibraryChangedNotification
//                        object:nil];
//}
//
//
//+ (void)removeObserverForAssetsLibraryChange:(id)anObserver {
//    NSNotificationCenter *defaultCenter = [NSNotificationCenter defaultCenter];
//    [defaultCenter removeObserver:anObserver
//                             name:ALAssetsLibraryChangedNotification
//                           object:nil];
//}


- (void)showLocalServiceErrorDialog: (NSError *) aError
{
//    __block UIAlertView *error = [[UIAlertView alloc] initWithTitle:@"Error" message:@"To pick images and create calendars, turn on the Location Service and grant this application the permission to access it." delegate:nil cancelButtonTitle:@"Confirm" otherButtonTitles: nil];
    __block UIAlertView *error = [[UIAlertView alloc] initWithTitle:@"Error" message:[NSString stringWithFormat: @"Error happened: %@.", aError] delegate:nil cancelButtonTitle:@"Confirm" otherButtonTitles: nil];
    [error show];
    [error release];
}


- (void)loadURLsWithCBTarget:(id)target andCBMethod:(SEL)cbSelector {
    NSLog(@"loadURLsWithCBTarget: andCBMethod: ");
    id cbTarget = [target retain];
    SEL cbMethod = cbSelector;
    
    NSMutableArray *urls = [[NSMutableArray alloc] init];
    
//    void (^assetResultBlock)(ALAsset *, NSUInteger, BOOL *) =
    ALAssetsGroupEnumerationResultsBlock resultAsset_b =
    ^(ALAsset *asset, NSUInteger index, BOOL *stop) {
        if (!*stop && asset) {
            ALAssetRepresentation *defaultRepresentation = [asset defaultRepresentation];
            [urls addObject:[defaultRepresentation url]];
        }
    };
	
//    void (^resultBlock)(ALAssetsGroup *, BOOL *) =
    ALAssetsLibraryGroupsEnumerationResultsBlock resultGroups_b = 
    ^(ALAssetsGroup *group, BOOL *stop) {
        if (*stop || !group) {
            [cbTarget performSelector:cbMethod withObject:urls];
        } else {
            [group setAssetsFilter:[ALAssetsFilter allPhotos]];
            [group enumerateAssetsUsingBlock:resultAsset_b];
        }
    };
    
//    void (^failureBlock)(NSError *) =
    ALAssetsLibraryAccessFailureBlock failureBlock = 
    ^(NSError *error) {
        [self showLocalServiceErrorDialog: error];
        NSLog(@"exception in enumerating assets. %@", error);
        [cbTarget performSelector:cbMethod withObject:urls];
    };
    
    ALAssetsGroupType targetGroupType = ALAssetsGroupAll;
    [_assetsLibrary enumerateGroupsWithTypes:targetGroupType
                                  usingBlock:resultGroups_b
                                failureBlock:failureBlock];
    
    [urls release];
    [cbTarget release];
}


// get thumbnail by URL synchronously
//- (UIImage *)getThumbnailOfAssetsByURL:(NSURL *)url {
//    __block UIImage *thumbnail = nil;
//    [_assetsLibrary 
//     assetForURL:url
//     resultBlock:^(ALAsset *asset) {
//         thumbnail = [[UIImage alloc] initWithCGImage:[asset thumbnail]];
//         NSLog(@"thumbnail: %@", thumbnail);
//     }
//     failureBlock:^(NSError *error) {
//         NSLog(@"Error happened in accessing assets by url. %@", error);                      
//     }];
//    return [thumbnail autorelease];
//}


// get thumbnail by URL asynchronously
- (void)getThumbnailOfAssetsWithCBByURL:(NSURL *)url andIndex: (NSInteger)index {
    __block UIImage *thumbnail = nil;
    [_assetsLibrary 
     assetForURL:url
     resultBlock:^(ALAsset *asset) {
         thumbnail = [[UIImage alloc] initWithCGImage:[asset thumbnail]];
         //NSLog(@"thumbnail: %@", thumbnail);
         [self.delegate onGetThumbnail: thumbnail withIndex: index];
     }
     failureBlock:^(NSError *error) {
         NSLog(@"Error happened in accessing assets by url. %@", error); 
         [self.delegate onGetThumbnail: thumbnail withIndex:index];
     }];
}

// get full resolution image by url synchronously
//- (UIImage *)getFullResolutionImageByURL:(NSURL *)url {
//    __block UIImage *fullResolutionImage = nil;
//    [_assetsLibrary 
//     assetForURL:url
//     resultBlock:^(ALAsset *asset) {
//         ALAssetRepresentation *dr = [asset defaultRepresentation];
//         fullResolutionImage = [[UIImage alloc] initWithCGImage:[dr fullResolutionImage]];
//     }
//     failureBlock:^(NSError *error) {
//         NSLog(@"Error happened in accessing assets by url. %@", error);                      
//     }];
//    return [fullResolutionImage autorelease];
//}


// get full resolution image by url asynchronously
- (void)getFullResolutionImageWithCBByURL:(NSURL *)url {
    __block UIImage *fullResolutionImage = nil;
    [_assetsLibrary 
     assetForURL:url
     resultBlock:^(ALAsset *asset) {
         ALAssetRepresentation *dr = [asset defaultRepresentation];
         fullResolutionImage = [[[UIImage alloc] initWithCGImage:[dr fullResolutionImage]] autorelease];
         [self.delegate onGetFullSizeImage:fullResolutionImage];
     }
     failureBlock:^(NSError *error) {
         NSLog(@"Error happened in accessing assets by url. %@", error);
         [self.delegate onGetFullSizeImage:fullResolutionImage];
     }];
    //return [fullResolutionImage autorelease];
}


// get full screen image by url asynchronously
- (void)getFullScreenImageWithCBByURL:(NSURL *)url {
    __block UIImage *fullScreenImage = nil;
    [_assetsLibrary 
     assetForURL:url
     resultBlock:^(ALAsset *asset) {
         ALAssetRepresentation *dr = [asset defaultRepresentation];
         fullScreenImage = [[[UIImage alloc] initWithCGImage:[dr fullScreenImage]] autorelease];
         [self.delegate onGetFullSizeImage:fullScreenImage];
     }
     failureBlock:^(NSError *error) {
         NSLog(@"Error happened in accessing assets by url. %@", error);
         [self.delegate onGetFullSizeImage:fullScreenImage];
     }];
    //return [fullResolutionImage autorelease];
}



- (NSDictionary *)getMetadataByUrl:(NSURL *)url {
    __block NSDictionary *metadata = nil;
    [_assetsLibrary assetForURL:url
                        resultBlock:^(ALAsset *asset) {
                            ALAssetRepresentation *defaultRepresentation = [asset defaultRepresentation];
                            metadata = [[defaultRepresentation metadata] copy];
                        }
                       failureBlock:^(NSError *error) {
                           NSLog(@"exception in accessing assets by url. %@", error);                      
                       }];
    return [metadata autorelease];
}


//// test mothod
//- (void)enumerationTest {
//    void (^assetResultBlock)(ALAsset *, NSUInteger, BOOL *) =
//    ^(ALAsset *asset, NSUInteger index, BOOL *stop) {
//        if (*stop) {
//            NSLog(@"stopped enumerating assets.");
//        } else if (!asset) {
//            NSLog(@"the end of the group.");
//        } else {
//            NSDictionary *urls = [asset valueForProperty:ALAssetPropertyURLs];
//            NSLog(@"%@", urls);
//        }
//    };
//	
//    void (^resultBlock)(ALAssetsGroup *, BOOL *) =
//    ^(ALAssetsGroup *group, BOOL *stop) {
//        if (*stop) {
//            NSLog(@"stopped enumerating groups.");
//        } else if (!group) {
//            NSLog(@"the end of enumation.");
//        } else {
//            NSString *groupName = [group valueForProperty:ALAssetsGroupPropertyName];
//            
//            ALAssetsFilter *photosFilter = [ALAssetsFilter allPhotos];
//            [group setAssetsFilter:photosFilter];
//            NSInteger numberOfPhotos = [group numberOfAssets];
//            NSLog(@"%d photos in %@", numberOfPhotos, groupName);
//            [group enumerateAssetsUsingBlock:assetResultBlock];
//            
//            ALAssetsFilter *videosFilter = [ALAssetsFilter allVideos];
//            [group setAssetsFilter:videosFilter];
//            NSInteger numberOfVideos = [group numberOfAssets];
//            NSLog(@"%d videos in %@", numberOfVideos, groupName);
//            [group enumerateAssetsUsingBlock:assetResultBlock];
//            
//            ALAssetsFilter *allFilter = [ALAssetsFilter allAssets];
//            [group setAssetsFilter:allFilter];
//            NSInteger numberOfAssets = [group numberOfAssets];
//            NSLog(@"%d assets in %@", numberOfAssets, groupName);
//            [group enumerateAssetsUsingBlock:assetResultBlock];
//        }
//    };
//    
//    void (^failureBlock)(NSError *) =
//    ^(NSError *error) {
//        NSLog(@"exception in enumerating assets. %@", error);
//    };
//	
//    // ALAssetsGroupType targetGroupType = ALAssetsGroupLibrary |
//    //   ALAssetsGroupAlbum |
//    //   ALAssetsGroupEvent |
//    //   ALAssetsGroupFaces |
//    //   ALAssetsGroupSavedPhotos;
//    ALAssetsGroupType targetGroupType = ALAssetsGroupAll;
//    [_assetsLibrary enumerateGroupsWithTypes:targetGroupType
//                                  usingBlock:resultBlock
//                                failureBlock:failureBlock];
//}


- (void)dealloc
{
    _assetsLibrary = nil;
    _delegate = nil;
    [super dealloc];
}

@end
