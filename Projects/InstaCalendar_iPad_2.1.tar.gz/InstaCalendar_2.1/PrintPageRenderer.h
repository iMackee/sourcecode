//
//  PrintPageRenderer.h
//  GalleryCalendar
//
//  Created by User on 11/11/03.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PrintPageRenderer : UIPrintPageRenderer
{
    UIImage *imageToPrint;
}

@property (readwrite, retain) UIImage *imageToPrint;

@end
