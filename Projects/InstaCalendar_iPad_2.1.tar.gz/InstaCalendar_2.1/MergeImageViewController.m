//
//  MergeImageViewController.m
//  GalleryCalendar_iPad
//
//  Created by 何 勇 on 11-11-19.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "MergeImageViewController.h"
#import "UIImageExtras.h"
#import "CalendarImageView.h"

//@interface MergeImageViewController (private)
//
//- (UIView *) generateCalendarWithYear: (NSInteger)year andMonth: (NSInteger)month;
//
//- (NSMutableArray *) generateCalendarListWithYear: (NSInteger)year;
//
//@end

#define IMAGE_WIDTH      72
#define IMAGE_HEIGHT     72
#define MONTH_WIDTH      72
#define MONTH_HEIGHT     72
#define IMAGE_MARGIN     4
#define CELL_DISTANCE    6

@implementation MergeImageViewController
@synthesize dateText = _dateText;

@synthesize imagesGallery=_imagesGallery;
//@synthesize monthList = _monthList;
@synthesize pickedImages = _pickedImages;
@synthesize images = _images;
@synthesize thumbs = _thumbs;
/*  attention!!
 the calendar views' tag must starts from 1 (positive) 
 and no other view with tag larger than 1 should be added 
 as subview of previewImageView, or will be removed */
@synthesize previewImageView = _previewImageView;
@synthesize currentImage=_currentImage;
//@synthesize calendarList=_calendarList;
@synthesize currentCalendarView=_currentCalendarView;


- (id) init {
	if ((self = [super init])) {
        _myAssetsLibraryAccessor = [[MyAssetsLibraryAccessor alloc] init];
        [_myAssetsLibraryAccessor setDelegate:self];        
	}
	return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        _myAssetsLibraryAccessor = [[MyAssetsLibraryAccessor alloc] init];
        [_myAssetsLibraryAccessor setDelegate:self];
        //NSLog(@"assets accessor inited: %@", _myAssetsLibraryAccessor);
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
//    NSLog(@"memory warning: %s", __FUNCTION__);
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    // Do not buffer the month list view for they can be got real time.
    // self.calendarList = [self generateCalendarListWithYear:_currentYear];
    
    // show picked images in a gallery
    [self presentImagesToGallary];  // set selected images' thumbnails on top
//    [self setMonthInList]; // set month list on buttom
    
    // draw default month
    NSDateComponents *comp = [[NSCalendar currentCalendar] components: NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate: [NSDate date]];
    _currentMonth = [comp month];
    _currentYear = [comp year];
    NSString *s = [NSString stringWithFormat:@"%d - %d", _currentYear, _currentMonth];
    self.dateText.title = s;
    
    // draw calendar
    UIView *view = [CalendarImageView makeCalendarWithYear:_currentYear andMonth:_currentMonth];
    view.tag = _currentMonth;
    self.currentCalendarView = view;
    [self.previewImageView addSubview:view];
    
    // add tap gesture to preview image view
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    tapGesture.numberOfTouchesRequired = 1;
    tapGesture.numberOfTapsRequired = 1;
    [self.previewImageView addGestureRecognizer:tapGesture];
    [tapGesture release];
    
    // swipe gesture for merge detai view
    UISwipeGestureRecognizer *swipeGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeAction:)];
    swipeGesture.direction = UISwipeGestureRecognizerDirectionLeft;
    [self.previewImageView addGestureRecognizer:swipeGesture];
    [swipeGesture release];
    
}

- (void)viewDidUnload
{
    [self setImagesGallery:nil];
    [self setPickedImages:nil];
    [self setThumbs:nil];
    [self setPreviewImageView:nil];
    [self setCurrentImage:nil];
//    [self setMonthList:nil];
    [self setDateText:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [_imagesGallery release];
//    [_monthList release];
    [_pickedImages release];
    [_images release];
    [_thumbs release];
    [_previewImageView release];
    [_currentImage release];
    [_currentCalendarView release];
    _myAssetsLibraryAccessor = nil;
    [_dateText release];
    [super dealloc];
}


/********************************************
 * about tag and index: 
 * the object index in array starts from 0
 * the tag of month view starts from 1
 ********************************************/

// private methods
//- (UIView *) generateCalendarWithYear: (NSInteger)year andMonth: (NSInteger)month
//{
//    UIView *cal = [CalendarImageView makeCalendarWithYear:year andMonth:month];
//    cal.tag = month;
//    return cal;
//}
//
//
//- (NSMutableArray *) generateCalendarListWithYear: (NSInteger)year
//{
//    NSMutableArray *calList = [[NSMutableArray alloc] initWithCapacity:12];
//    for (int i = 0; i < 12; i++) {
//        UIView *cal = [self generateCalendarWithYear:year andMonth:i+1];
//        [calList addObject:cal];
//    }
//    return [calList autorelease];
//}




- (IBAction)cancelButton:(id)sender {
//    NSLog(@"cancelButton");
    [self dismissModalViewControllerAnimated:YES];
}


- (IBAction)mergeButton:(id)sender {
//    NSLog(@"mergeButton");
    MergeDetailViewController *detail = [[MergeDetailViewController alloc] initWithNibName:@"MergeDetailViewController" bundle:nil];
    [detail presentImage:self.currentImage];
    [detail setSeletedYear:_currentYear month:_currentMonth];
    if (self.currentCalendarView) {
        [detail presentCalendar:self.currentCalendarView];
    } else {
        //        [detail presentCalendar:[self.calendarList objectAtIndex:_selectedCalendarIndex]];
        // do not use buffer
        [detail presentCalendar:[CalendarImageView makeCalendarWithYear:_currentYear andMonth:_currentMonth]];
    }
    [detail.view bringSubviewToFront:detail.toolBar];
    detail.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController:detail animated:YES];
    [detail setDelegate:self];
    [detail release];
    [self.previewImageView addSubview:self.currentCalendarView];
}

- (void)redrawCalendar
{
    NSInteger count = [self.previewImageView.subviews count];
    for (int i = 0; i < count; i++) {
        UIView *cal = [self.previewImageView.subviews objectAtIndex:i];
        NSInteger tag = cal.tag;
        if (tag >= 1) {
            [cal removeFromSuperview];
        } 
    }
    
    UIView *cal = nil;
    cal = [CalendarImageView makeCalendarWithYear:_currentYear andMonth:_currentMonth];
    cal.tag = _currentMonth;
//    cal.transform = savedCalTransform;
//    cal.center = savedCalCenter;
    self.currentCalendarView = cal;
//    [self addGestureRecognizerToCalendarView];
    [self.previewImageView addSubview:cal];
}


- (IBAction)nextMonth:(id)sender {
    if (12 == _currentMonth) {
        _currentYear++;
        _currentMonth = 1;
    } else {
        _currentMonth++;
    }
    NSString *s = [NSString stringWithFormat:@"%d - %d", _currentYear, _currentMonth];
    self.dateText.title = s;
    
    [self redrawCalendar];
}

- (IBAction)prevMonth:(id)sender {
    if (1 == _currentMonth) {
        _currentYear--;
        _currentMonth = 12;
    } else {
        _currentMonth--;
    }
    NSString *s = [NSString stringWithFormat:@"%d - %d", _currentYear, _currentMonth];
    self.dateText.title = s;
    
    [self redrawCalendar];
}


#pragma mark - public methods
- (void) setChosenImages: (NSMutableArray *) images
{
    //    self.pickedImages = [[[NSMutableArray alloc] initWithArray:images] autorelease];
    self.pickedImages = [images autorelease];
}

- (void) setChosenDate: (NSDate *)date
{
    NSDateComponents *comp = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate: date];
    _currentYear = [comp year];
    _currentMonth = [comp month];
//    NSLog(@"current year: %d, and month: %d", _currentYear, _currentMonth);
}

- (void) presentImagesToGallary
{
//    NSLog(@"presentImagesToGallery");
    NSInteger count = [self.pickedImages count];
    _thumbCount = count;
//    NSLog(@"picked images: %d", count);
    
    for (int i = 0; i < count; i++) {
//        NSLog(@"URL: %@", [self.pickedImages objectAtIndex:i]);
        
        // use asynchronous method because the thumbnail are returned asynchronously
        [_myAssetsLibraryAccessor getThumbnailOfAssetsWithCBByURL:[self.pickedImages objectAtIndex:i] andIndex:i];
        
    }
}


#pragma mark - MyAssetsLibraryThumbnailDelegate
- (void)onGetThumbnail:(UIImage *)thumbnail withIndex:(NSInteger)index
{
    //    NSLog(@"onGetThumbnail: %d : %@", index, thumbnail);
    CGRect rect = CGRectMake(index * (IMAGE_WIDTH + CELL_DISTANCE) + IMAGE_MARGIN, IMAGE_MARGIN, IMAGE_WIDTH, IMAGE_HEIGHT);
    UIButton *thumbView = [UIButton buttonWithType:UIButtonTypeCustom];
    thumbView.frame = rect;
    if (thumbnail) {
        [thumbView setImage:thumbnail forState:UIControlStateNormal];
    } else {
        [thumbView setImage:[UIImage imageNamed:@"icon.png"] forState:UIControlStateNormal];
    }
    
    [thumbView addTarget:self action:@selector(onThumbClicked:) forControlEvents:UIControlEventTouchUpInside];
    thumbView.tag = index;
    [self.imagesGallery addSubview:thumbView];
    
    [self.imagesGallery setContentSize:CGSizeMake((_thumbCount + 1) * (IMAGE_WIDTH + CELL_DISTANCE), IMAGE_HEIGHT + IMAGE_MARGIN)];
    
    //    [_myAssetsLibraryAccessor getFullResolutionImageWithCBByURL:[self.pickedImages objectAtIndex:0]];
    [_myAssetsLibraryAccessor getFullScreenImageWithCBByURL:[self.pickedImages objectAtIndex:0]];
}



// call back method of asynchronous get full size method
-(void)onGetFullSizeImage:(UIImage *)image
{
    self.currentImage = image; // may be nil when image can not be retrieved from library
    if (image) {
        [self.previewImageView setImage:image];
    } else {
        // TODO: change a proper file to replace icon.png
        // present a default image as icon or start up image.
        [self.previewImageView setImage:[UIImage imageNamed:@"Default.png"]];
    }
}

//- (void) setMonthInList
//{
////    NSLog(@"setMonthInList");
//    for (int i = 0; i < 12; i++) {
//        UIButton *view = [[UIButton alloc] initWithFrame:CGRectMake(i * (CELL_DISTANCE + MONTH_WIDTH) + IMAGE_MARGIN, IMAGE_MARGIN, MONTH_WIDTH, MONTH_HEIGHT)];
//        //        // create UILable with frame, replaced by icons
//        //        UILabel *mon = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
//        //        
//        //        mon.textAlignment = UITextAlignmentCenter;
//        //        mon.backgroundColor = [UIColor clearColor];
//        //        mon.textColor = [UIColor blackColor];
//        //        
//        //        mon.layer.borderColor = [[UIColor grayColor] CGColor];
//        //        mon.layer.borderWidth = 2.0f;            
//        //        
//        //        mon.font = [UIFont fontWithName:@"Courier" size:30.0f];
//        //        mon.text = [NSString stringWithFormat:@"%d", i+1];
//        //        [view addSubview:mon];
//        view.tag = i;
//        [view setImage:[UIImage imageNamed:[NSString stringWithFormat:@"m%d.png", i+1]] forState:UIControlStateNormal];
//        [view addTarget:self action:@selector(onMonthClicked:) forControlEvents:UIControlEventTouchUpInside];
//        
//        [self.monthList addSubview:view];
//        //        [mon release];
//        [view release];
//    }
//    [self.monthList setContentSize:CGSizeMake((12 + 1) * (MONTH_WIDTH + CELL_DISTANCE), MONTH_HEIGHT + IMAGE_MARGIN)];
//    
//}

- (IBAction)onThumbClicked:(id)sender
{
    UIButton *view = (UIButton *)sender;
    _imageIndex = view.tag;
//    NSLog(@"Clicked thumb number: %d", _imageIndex);
    // use the asynchronou method
    //    [_myAssetsLibraryAccessor getFullResolutionImageWithCBByURL:[self.pickedImages objectAtIndex:_imageIndex]];
    [_myAssetsLibraryAccessor getFullScreenImageWithCBByURL:[self.pickedImages objectAtIndex:_imageIndex]];
}

//- (IBAction)onMonthClicked:(id)sender
//{
//    UIButton *mb = (UIButton *)sender;
//    
//    // remove previous month
//    NSInteger count = [self.previewImageView.subviews count];
//    //NSLog(@"subview count: %d", count);
//    for (int i = 0; i < count; i++) {
//        UIView *cal = [self.previewImageView.subviews objectAtIndex:i];
//        NSInteger tag = cal.tag; // tag by month, starting from 1
//        //NSLog(@"subview tag: %d", tag);
//        if (tag >= 1) {
//            [cal removeFromSuperview];
//        } 
//    }
//    
//    _selectedCalendarIndex = mb.tag;            // tag by view, starting from 0
//    _selectedMonth = _selectedCalendarIndex + 1;// tag by month, starting from 1
//    
//    //    UIView *cal = [self.calendarList objectAtIndex:_selectedCalendarIndex];
//    // do not use buffer
//    UIView *cal = [CalendarImageView makeCalendarWithYear:_currentYear andMonth:_selectedMonth];
//    cal.tag = _selectedMonth;
//    self.currentCalendarView = cal;
//    
//    [self.previewImageView addSubview:cal];
//}



// tap action
- (void)tapAction: (UITapGestureRecognizer *)sender
{
    //NSLog(@"tapAction");
    // remove previous month
    NSInteger count = [self.previewImageView.subviews count];
    //NSLog(@"subview count: %d", count);
    for (int i = 0; i < count; i++) {
        UIView *cal = [self.previewImageView.subviews objectAtIndex:i];
        NSInteger tag = cal.tag; // tag by month, starting from 1
        //NSLog(@"subview tag: %d", tag);
        if (tag >= 1) {
            [cal removeFromSuperview];
        } 
    }
    
    UIView *cal = nil;
    cal = [CalendarImageView changeCalendarColorWithYear:_currentYear andMonth:_currentMonth];
    cal.tag = _currentMonth;
    self.currentCalendarView = cal;
    [self.previewImageView addSubview:cal];
}


// swipe to go to merge detail view
- (void)swipeAction: (UITapGestureRecognizer *)sender
{
    MergeDetailViewController *detail = [[MergeDetailViewController alloc] initWithNibName:@"MergeDetailViewController" bundle:nil];
    if (self.currentImage) {
        [detail presentImage:self.currentImage];
    } else {
        UIAlertView *imageNil = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Sorry, the image you have picked can not be used, try another one?" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [imageNil show];
        [imageNil release];
        [detail release];
        return;
    }
    
    [detail setSeletedYear:_currentYear month:_currentMonth];
    if (self.currentCalendarView) {
        [detail presentCalendar:self.currentCalendarView];
    } else {
        [detail presentCalendar:[CalendarImageView makeCalendarWithYear:_currentYear andMonth:_currentMonth]];
    }
    [detail.view bringSubviewToFront:detail.toolBar];
    detail.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController:detail animated:YES];
    [detail setDelegate:self];
    [detail release];
    [self.previewImageView addSubview:self.currentCalendarView];
}



#pragma mark - protocal CalendarMergeDelegate
- (void) onCalendarMergedOfMonth: (NSInteger)month
{
//    NSLog(@"onCalendarMerged");
    // TODO: mark the month that has been merged
}

@end