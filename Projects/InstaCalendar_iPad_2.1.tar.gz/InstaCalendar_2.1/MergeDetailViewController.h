//
//  MergeDetailViewController.h
//  GalleryCalendar_iPad
//
//  Created by 何 勇 on 11-11-19.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <MessageUI/MessageUI.h>
#import <Twitter/TwRequest.h>
#import <Twitter/TWTweetComposeViewController.h>

@protocol CalendarMergeDelegate <NSObject>

@optional
- (void) onCalendarMergedOfMonth: (NSInteger)month;

@end

@interface MergeDetailViewController : UIViewController <UIActionSheetDelegate, MFMailComposeViewControllerDelegate> 
{
    UIToolbar *_toolBar;
    UIActionSheet *_actionSheet;
    UIPrintInteractionController *_printController;
    
    UIImage *_image;
    UIView *_currentCalendarView;
    UIImageView *_currentImageView;
    NSInteger _currentYear;
    NSInteger _currentMonth;
    BOOL _toolBarHidden;
    BOOL _isPrintControllerShown;
    UIInterfaceOrientation _currentOrientation;
    
    CGAffineTransform currentTransform;
    
    id<CalendarMergeDelegate> _delegate;
}

@property (nonatomic, retain) UIActionSheet *actionSheet;
@property (nonatomic, retain) UIPrintInteractionController *printController;

@property (nonatomic, retain) id<CalendarMergeDelegate> delegate;

@property (nonatomic, retain) UIImage *image;

@property (nonatomic, retain) UIView *currentCalendarView;

@property (nonatomic, retain) UIView *currentImageView;

@property (nonatomic, retain) IBOutlet UIToolbar *toolBar;
@property (retain, nonatomic) IBOutlet UIBarButtonItem *actionBarItem;
@property (retain, nonatomic) IBOutlet UIView *mergeView;


- (void)presentImage: (UIImage *)image;
- (void)presentCalendar: (UIView *)calendar;
- (void)setSeletedYear: (NSInteger)year month: (NSInteger)month;

- (IBAction)cancelMerge:(id)sender;
- (IBAction)confirmMerge:(id)sender;
- (IBAction)previewMerge:(id)sender;

@end
