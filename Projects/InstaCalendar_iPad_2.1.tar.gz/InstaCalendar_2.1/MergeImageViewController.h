//
//  MergeImageViewController.h
//  GalleryCalendar_iPad
//
//  Created by 何 勇 on 11-11-19.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "MergeDetailViewController.h"
#import "MyAssetsLibraryAccessor.h"

@interface MergeImageViewController : UIViewController <CalendarMergeDelegate, MyAssetsLibraryThumbnailDelegate> {
    UIScrollView *_imagesGallery;
    
    NSMutableArray *_pickedImages;
	NSMutableArray *_thumbs;
    UIImageView *_previewImageView;
    UIImage *_currentImage;
    UIView *_currentCalendarView;
    
    MyAssetsLibraryAccessor *_myAssetsLibraryAccessor;
    
    NSInteger _imageIndex;
    NSInteger _currentYear;
    NSInteger _currentMonth;
//    NSInteger _selectedMonth;
    NSInteger _selectedCalendarIndex;  // calendar view index in calendar list
    NSInteger _thumbCount;
}

@property (nonatomic, retain) NSMutableArray *pickedImages;
@property (nonatomic, retain) NSMutableArray *images;
@property (nonatomic, retain) NSMutableArray *thumbs;
@property (nonatomic, retain) UIView *currentCalendarView;
@property (nonatomic, retain) UIImage *currentImage;

@property (nonatomic, retain) IBOutlet UIImageView *previewImageView;
@property (nonatomic, retain) IBOutlet UIScrollView *imagesGallery;
//@property (retain, nonatomic) IBOutlet UIScrollView *monthList;
@property (retain, nonatomic) IBOutlet UIBarButtonItem *dateText;


// public methods
- (void) setChosenImages: (NSMutableArray *) images;
- (void) setChosenDate: (NSDate *)date;
- (void) presentImagesToGallary;
//- (void) setMonthInList;

// IBAction
- (IBAction)cancelButton:(id)sender;
- (IBAction)mergeButton:(id)sender;
- (IBAction)nextMonth:(id)sender;
- (IBAction)prevMonth:(id)sender;

@end
