//
//  DatePickerController.m
//  GalleryCalendar_iPad
//
//  Created by 何 勇 on 11-11-19.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "DatePickerController.h"

@implementation DatePickerController
@synthesize datePicker;
@synthesize pickedDate;
@synthesize delegate=_delegate;

/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [self setDatePicker:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    pickedDate = [self.datePicker date];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return YES;
}

- (void)dealloc {
    [datePicker release];
    [super dealloc];
}
- (IBAction)setToday:(id)sender {
    [self.datePicker setDate:[NSDate date] animated:YES];
    [self.delegate onPickedDate:[NSDate date]];
}

- (IBAction)pickFinish:(id)sender {
    pickedDate = [self.datePicker date];
    [self.delegate onClickedFinish];
}

- (IBAction)datePickerSelected:(id)sender {
    pickedDate = [self.datePicker date];
    [self.delegate onPickedDate:pickedDate];
}
@end
