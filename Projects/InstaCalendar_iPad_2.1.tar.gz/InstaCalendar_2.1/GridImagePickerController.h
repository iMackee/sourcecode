//
//  GridImagePickerController.h
//  GalleryCalendar_iPad
//
//  Created by 何 勇 on 11-11-21.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AssetsLibrary/AssetsLibrary.h>

@interface GridImagePickerController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
    ALAssetsLibrary *_assetsLibrary;
    NSMutableArray *_groups;
    NSMutableArray *_assets;
    NSMutableArray *_sections;
    NSMutableArray *_checkedImages;
    NSMutableArray *_imagesURLs;
    
    NSInteger _pickCounter;
    NSInteger _tagCounter;
}

@property (nonatomic, retain) ALAssetsLibrary *assetsLibrary;
@property (nonatomic, retain) NSMutableArray *groups;
@property (nonatomic, retain) NSMutableArray *assets;
@property (nonatomic, retain) NSDate *chosenDate;
@property (nonatomic, retain) NSMutableArray *sections;
@property (nonatomic, retain) NSMutableArray *checkedImages;
@property (nonatomic, retain) NSMutableArray *imagesURLs;

@property (retain, nonatomic) IBOutlet UIToolbar *toolbar;
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (retain, nonatomic) IBOutlet UITableView *tableView;

- (IBAction)cancelButton:(id)sender;
- (IBAction)nextButton:(id)sender;
@end
