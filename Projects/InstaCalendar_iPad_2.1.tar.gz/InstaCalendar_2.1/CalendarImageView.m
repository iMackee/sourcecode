//
//  CalendarImageView.m
//  GalleryCalendar
//
//  Created by User on 11/11/05.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "CalendarImageView.h"

@interface CalendarImageView (private) 
+ (NSString *)getMonthNameFromNumber: (NSInteger)month;
+ (BOOL)isLeapYear: (NSInteger)year;
+ (NSInteger)getDaysInMonth: (NSInteger) month ofYear: (NSInteger) year;
+ (BOOL)isTodayWithYear: (NSInteger)year Month:(NSInteger)month Day:(NSInteger)day;
+ (UIColor *)getWeekEndColorByIndex: (NSInteger)index;
+ (UIColor *)getWeekDayColorByIndex: (NSInteger)index;
@end


#define DAY_WIDTH      38 //30
#define DAY_HEIGHT     24 //18
#define CALENDAR_WIDTH 450//270
#define WEEK_DAYS      7
#define WEEK_OFFSET    72 //60
#define YEAR_WIDTH     70
#define MONTH_WIDTH    70
#define CALENDAR_LINES 6

#define MONTH_OFFSET_Y 90
#define YEAR_OFFSET_Y -10

#define MAX_COLOR      10

@implementation CalendarImageView

static NSString *defaultFont = @"ArialMT";

#pragma mark - private methods
+ (NSString *)getMonthNameFromNumber: (NSInteger)month
{
    switch (month) {
        case 1:
            return @"Jan";
        case 2:
            return @"Feb";
        case 3:
            return @"Mar";
        case 4:
            return @"Apr";
        case 5:
            return @"May";
        case 6:
            return @"Jun";
        case 7:
            return @"Jul";
        case 8:
            return @"Aug";
        case 9:
            return @"Sep";
        case 10:
            return @"Oct";
        case 11:
            return @"Nov";
        case 12:
            return @"Dec";
        default:
            break;
    }
    return @"";
}


+ (BOOL)isLeapYear: (NSInteger)year
{
    return ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
}


+ (NSInteger)getDaysInMonth: (NSInteger) month ofYear: (NSInteger) year
{
    switch (month) {
        case 1:
            return 31;
        case 2:
            return [self isLeapYear: year] ? 29 : 28;
        case 3:
            return 31;
        case 4:
            return 30;
        case 5:
            return 31;
        case 6:
            return 30;
        case 7:
            return 31;
        case 8:
            return 31;
        case 9:
            return 30;
        case 10:
            return 31;
        case 11:
            return 30;
        case 12:
            return 31;
        default:
            NSAssert(NO, @"Out of range!");
            break;
    }
    return 0;
    
}


+ (BOOL)isTodayWithYear: (NSInteger)year Month:(NSInteger)month Day:(NSInteger)day
{
    // today
    NSDateComponents *todayComp = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate: [NSDate date]];
    
    NSInteger _day = [todayComp day];    
    NSInteger _month = [todayComp month];
    NSInteger _year = [todayComp year];
    
    return (_year == year && _month == month && _day == day);
}


+ (UIColor *)getWeekEndColorByIndex: (NSInteger)index
{
    switch (index) {
        case 0:
            return [UIColor colorWithRed:0.5 green:0.5 blue:1.0 alpha:1.0];
            break;
            
        case 1:
            return [UIColor redColor];
            break;
            
        case 2:
            return [UIColor cyanColor];
            break;
            
        case 3:
            return [UIColor colorWithRed:0.5 green:1.0 blue:0.5 alpha:1.0];
            break;
            
        case 4:
            return [UIColor colorWithRed:1.0 green:0.5 blue:0.5 alpha:1.0];
            break;
            
        case 5:
            return [UIColor redColor];
            break;
            
        case 6:
            return [UIColor cyanColor];
            break;
            
        case 7:
            return [UIColor greenColor];
            break;
            
        case 8:
            return [UIColor redColor];
            break;
            
        case 9:  // this influents the number of MAX_COLOR
            return [UIColor greenColor];
            break;

        default:
            break;
    }
    return [UIColor whiteColor];
}

+ (UIColor *)getWeekDayColorByIndex: (NSInteger)index
{
    switch (index) {
        case 0:
            return [UIColor whiteColor];
            break;
            
        case 1:
            return [UIColor blackColor];
            break;
            
        case 2:
            return [UIColor blackColor];
            break;
            
        case 3:
            return [UIColor blackColor];
            break;
            
        case 4:
            return [UIColor colorWithRed:0.1 green:0.1 blue:0.1 alpha:1.0];
            break;
            
        case 5:
            return [UIColor yellowColor];
            break;
            
        case 6:
            return [UIColor yellowColor];
            break;
            
        case 7:
            return [UIColor yellowColor];
            break;
            
        case 8:
            return [UIColor whiteColor];
            break;
            
        case 9:  // this influents the number of MAX_COLOR
            return [UIColor whiteColor];
            break;
            
        default:
            break;
    }
    return [UIColor colorWithRed:0.5 green:0.5 blue:1.0 alpha:1.0];
}



#pragma mark - public methods
// used in main view
+ (UIImageView *)makeCalendar: (NSDate *) date
{
    NSDateComponents *refComp;
    if(!date) {
//        NSLog(@"Use today");
        refComp = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate: [NSDate date]];
    } else {
        // get chosen date
        refComp = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate: date];
    }
    
    //NSInteger day = [refComp day];    
    NSInteger selectedMonth = [refComp month];
    NSInteger selectedYear = [refComp year];
    
    // set first day of the chosen month
    NSDateComponents *firstDayComp = [[NSDateComponents alloc] init];
    [firstDayComp setDay:1];
    [firstDayComp setMonth:selectedMonth];
    [firstDayComp setYear:selectedYear];
    
    // Use localized calendar with system setting
    NSCalendar *userCalendar = [[NSLocale currentLocale] objectForKey:NSLocaleCalendar];
    NSDate *userDate = [userCalendar dateFromComponents:firstDayComp];
    [firstDayComp release];
    NSDateComponents *weekdayComponents =
    [userCalendar components:NSWeekdayCalendarUnit fromDate:userDate];
    int firstWeekDay = [weekdayComponents weekday];
/*  -- can only use localized calendar or gregorian calendar --
    // use gregorian calendar
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSGregorianCalendar];
    NSDate *userDate = [gregorian dateFromComponents:firstDayComp];
    [firstDayComp release];
    NSDateComponents *weekdayComponents =
    [gregorian components:NSWeekdayCalendarUnit fromDate:userDate];
    int firstWeekDay = [weekdayComponents weekday];
*/
 
//    NSLog(@"First week day: %d", firstWeekDay);
    
    int daysOfMonth = [self getDaysInMonth:selectedMonth ofYear:selectedYear];

    CGRect rect;
    // start from sunday
    if(daysOfMonth + firstWeekDay - 1 > 35) {
        rect = CGRectMake(20, 60, CALENDAR_WIDTH, DAY_HEIGHT * (CALENDAR_LINES + 1));
    } else {
        rect = CGRectMake(20, 60, CALENDAR_WIDTH, DAY_HEIGHT * CALENDAR_LINES);
    }
    
    UIImageView *cal = [[UIImageView alloc] initWithFrame:rect];
    [cal setBackgroundColor:[UIColor clearColor]];  // set to transparent
    
    // set title of week days - gregorian format
    // show as "Sun  Mon  Tue  Web  Thu  Fri  Sat"
    NSArray *week_day_titles = [NSArray arrayWithObjects:@"S", @"M", @"T", @"W", @"T", @"F", @"S", nil];
    for (int i = 0; i < WEEK_DAYS; i++) {
        UILabel *weekDay = [[UILabel alloc] initWithFrame:CGRectMake(i*DAY_WIDTH + WEEK_OFFSET, 0, DAY_WIDTH, DAY_HEIGHT)];
        weekDay.backgroundColor = [UIColor clearColor];
        weekDay.textAlignment = UITextAlignmentCenter;
        weekDay.textColor = [UIColor orangeColor];
        weekDay.font = [UIFont fontWithName:defaultFont size:18.0f]; // Font with the same width
        weekDay.text = [week_day_titles objectAtIndex:i];
        [cal addSubview:weekDay];
        [weekDay release];
    }
    

    int row = 1;
	int col = 0;
    BOOL IS_TODAY = FALSE;
	for(int i = 0; i < daysOfMonth; ++i) {
        if([self isTodayWithYear:selectedYear Month:selectedMonth Day:i + 1]) {
            IS_TODAY = TRUE;
        } else {
            IS_TODAY = FALSE;
        }
        
        BOOL isFirstLine = TRUE;
        UILabel *dayView = nil;
        if (row == 1) {
            dayView = [[UILabel alloc] initWithFrame:CGRectMake((col + firstWeekDay - 1)*DAY_WIDTH + WEEK_OFFSET, row*DAY_HEIGHT, DAY_WIDTH, DAY_HEIGHT)];
            if (i + firstWeekDay == WEEK_DAYS) {
                isFirstLine = FALSE;
            }
        } else {
            dayView = [[UILabel alloc] initWithFrame:CGRectMake(col*DAY_WIDTH + WEEK_OFFSET, row*DAY_HEIGHT, DAY_WIDTH, DAY_HEIGHT)];
        }
        dayView.textAlignment = UITextAlignmentCenter;
        dayView.backgroundColor = [UIColor clearColor];
        // set today to red and bigger font
        if (IS_TODAY) {
            dayView.textColor = [UIColor redColor];
            // add a border around the text - QuartzCore/QuartzCore.h
            dayView.layer.borderColor = [[UIColor redColor] CGColor];
            dayView.layer.borderWidth = 2.0f;            
        } else {
            dayView.textColor = [UIColor whiteColor];
        }
        dayView.font = [UIFont fontWithName:defaultFont size:21.0f];
        dayView.text = [NSString stringWithFormat:@"%d", i+1];
        [cal addSubview:dayView];
        [dayView release];
        
        // update column and row index
        if (!isFirstLine || col == WEEK_DAYS - 1) {
            col = 0;
            row ++;
        } else {
            col ++;
        }
	}
    
    // add year text
    UILabel *yearView = [[UILabel alloc] initWithFrame:CGRectMake(0, YEAR_OFFSET_Y, WEEK_OFFSET, YEAR_WIDTH)];
    yearView.backgroundColor = [UIColor clearColor];
    yearView.textColor = [UIColor cyanColor];
    yearView.font = [UIFont fontWithName:defaultFont size:25.0f];
    yearView.text = [NSString stringWithFormat:@"%d", selectedYear];
    [cal addSubview:yearView];
    [yearView release];
    
    // add month text
    UILabel *monthView = [[UILabel alloc] initWithFrame:CGRectMake(0, MONTH_OFFSET_Y, WEEK_OFFSET, MONTH_WIDTH)];
    monthView.backgroundColor = [UIColor clearColor];
    monthView.textColor = [UIColor orangeColor];
    monthView.font = [UIFont fontWithName:defaultFont size:32.0f]; // Font with the same width
    monthView.text = [self getMonthNameFromNumber:selectedMonth];
    [cal addSubview:monthView];
    [monthView release];

    return [cal autorelease];
}


// used in merge view
+ (UIView *)makeCalendarWithYear: (NSInteger)year andMonth: (NSInteger)month
{
//    NSLog(@"makeCalendar, year: %d, month: %d", year, month);
    
    // set first day of the chosen month
    NSDateComponents *firstDayComp = [[NSDateComponents alloc] init];
    [firstDayComp setDay:1];
    [firstDayComp setMonth:month];
    [firstDayComp setYear:year];
    
    // Use localized calendar with system setting
    NSCalendar *userCalendar = [[NSLocale currentLocale] objectForKey:NSLocaleCalendar];
    NSDate *userDate = [userCalendar dateFromComponents:firstDayComp];
    [firstDayComp release];
    
    NSDateComponents *weekdayComponents = [userCalendar components:NSWeekdayCalendarUnit fromDate:userDate];
    int firstWeekDay = [weekdayComponents weekday];
//    NSLog(@"First week day: %d", firstWeekDay);
    
    int daysOfMonth = [self getDaysInMonth:month ofYear:year];
    
    CGRect rect;
    // start from sunday
    if(daysOfMonth + firstWeekDay - 1 > 35) {
        rect = CGRectMake(20, 60, CALENDAR_WIDTH, DAY_HEIGHT * (CALENDAR_LINES + 1));
    } else {
        rect = CGRectMake(20, 60, CALENDAR_WIDTH, DAY_HEIGHT * CALENDAR_LINES);
    }
    
    UIView *cal = [[UIView alloc] initWithFrame:rect];
    [cal setBackgroundColor:[UIColor clearColor]];
    
    // set title of week days - gregorian format
    NSArray *week_day_titles = [NSArray arrayWithObjects:@"S", @"M", @"T", @"W", @"T", @"F", @"S", nil];
    for (int i = 0; i < WEEK_DAYS; i++) {
        UILabel *weekDay = [[UILabel alloc] initWithFrame:CGRectMake(i*DAY_WIDTH + WEEK_OFFSET, 0, DAY_WIDTH, DAY_HEIGHT)];
        weekDay.backgroundColor = [UIColor clearColor];
        weekDay.textAlignment = UITextAlignmentCenter;
        if (i == 0 || i == 6) { // change font color for Sunday and Saturday
            weekDay.textColor = [UIColor colorWithRed:0.5 green:0.5 blue:1.0 alpha:1.0];
        } else {
            weekDay.textColor = [UIColor blackColor];
        }
        weekDay.font = [UIFont fontWithName:defaultFont size:18.0f]; // Font with the same width
        weekDay.text = [week_day_titles objectAtIndex:i];
        [cal addSubview:weekDay];
        [weekDay release];
    }
    
    
    int row = 1;
	int col = 0;
	for(int i = 0; i < daysOfMonth; ++i) {
        
        BOOL isFirstLine = TRUE;
        UILabel *dayView = nil;
        if (row == 1) {
            dayView = [[UILabel alloc] initWithFrame:CGRectMake((col + firstWeekDay - 1)*DAY_WIDTH + WEEK_OFFSET, row*DAY_HEIGHT, DAY_WIDTH, DAY_HEIGHT)];

            if (i + firstWeekDay == WEEK_DAYS) {
                isFirstLine = FALSE;
            }
            
            if((firstWeekDay == 1 && col == 0) || (firstWeekDay + col == 7)) {
//                NSLog(@"paint blue: %d", i);
                dayView.textColor = [UIColor colorWithRed:0.5 green:0.5 blue:1.0 alpha:1.0];
            } else {
                dayView.textColor = [UIColor blackColor];
            }
        } else {
            dayView = [[UILabel alloc] initWithFrame:CGRectMake(col*DAY_WIDTH + WEEK_OFFSET, row*DAY_HEIGHT, DAY_WIDTH, DAY_HEIGHT)];
            if (col == 0 || col == 6) { // change font color for sunday and saturday
                dayView.textColor = [UIColor colorWithRed:0.5 green:0.5 blue:1.0 alpha:1.0];
            } else {
                dayView.textColor = [UIColor blackColor];
            }
        }
        dayView.textAlignment = UITextAlignmentCenter;
        dayView.backgroundColor = [UIColor clearColor];
        
        // set today to red and bigger font
//        if (IS_TODAY) {
//            dayView.textColor = [UIColor redColor];
//            // add a border around the text - QuartzCore/QuartzCore.h
//            dayView.layer.borderColor = [[UIColor redColor] CGColor];
//            dayView.layer.borderWidth = 2.0f;            
//        } else {
//            dayView.textColor = [UIColor blackColor];
//        }
//        dayView.font = [UIFont fontWithName:@"Courier" size:21.0f];
        dayView.font = [UIFont fontWithName:defaultFont size:21.0f];
        dayView.text = [NSString stringWithFormat:@"%d", i+1];
        [cal addSubview:dayView];
        [dayView release];
        
        // update column and row index
        if (!isFirstLine || col == WEEK_DAYS - 1) {
            col = 0;
            row ++;
        } else {
            col ++;
        }
	}
    
    // add year text
    UILabel *yearView = [[UILabel alloc] initWithFrame:CGRectMake(0, YEAR_OFFSET_Y, WEEK_OFFSET, YEAR_WIDTH)];
    yearView.backgroundColor = [UIColor clearColor];
    yearView.textColor = [UIColor cyanColor];
    yearView.font = [UIFont fontWithName:defaultFont size:25.0f];
    yearView.text = [NSString stringWithFormat:@"%d", year];
    [cal addSubview:yearView];
    [yearView release];
    
    // add month text
    UILabel *monthView = [[UILabel alloc] initWithFrame:CGRectMake(0, MONTH_OFFSET_Y, WEEK_OFFSET, MONTH_WIDTH)];
    monthView.backgroundColor = [UIColor clearColor];
    monthView.textColor = [UIColor blackColor];
    monthView.font = [UIFont fontWithName:defaultFont size:32.0f]; // Font with the same width
    monthView.text = [self getMonthNameFromNumber:month];
    [cal addSubview:monthView];
    [monthView release];
    
    return [cal autorelease];
}


// round shift color
+ (UIView *)changeCalendarColorWithYear: (NSInteger) year andMonth: (NSInteger) month
{
//    NSLog(@"changeCalendarColorWithYear, year: %d, month: %d", year, month);
    
    _increment = (_increment + 1) % MAX_COLOR;
//    NSLog(@"increment: %d", _increment);
    
    // set first day of the chosen month
    NSDateComponents *firstDayComp = [[NSDateComponents alloc] init];
    [firstDayComp setDay:1];
    [firstDayComp setMonth:month];
    [firstDayComp setYear:year];
    
    // Use localized calendar with system setting
    NSCalendar *userCalendar = [[NSLocale currentLocale] objectForKey:NSLocaleCalendar];
    NSDate *userDate = [userCalendar dateFromComponents:firstDayComp];
    [firstDayComp release];
    
    NSDateComponents *weekdayComponents = [userCalendar components:NSWeekdayCalendarUnit fromDate:userDate];
    int firstWeekDay = [weekdayComponents weekday];
//    NSLog(@"First week day: %d", firstWeekDay);
    
    int daysOfMonth = [self getDaysInMonth:month ofYear:year];
    
    CGRect rect;
    // start from sunday
    if(daysOfMonth + firstWeekDay - 1 > 35) {
        rect = CGRectMake(20, 60, CALENDAR_WIDTH, DAY_HEIGHT * (CALENDAR_LINES + 1));
    } else {
        rect = CGRectMake(20, 60, CALENDAR_WIDTH, DAY_HEIGHT * CALENDAR_LINES);
    }
    
    UIView *cal = [[UIView alloc] initWithFrame:rect];
//    [cal setBackgroundColor:[UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:0.5]];
    [cal setBackgroundColor:[UIColor clearColor]];
    
    // set title of week days - gregorian format
    NSArray *week_day_titles = [NSArray arrayWithObjects:@"S", @"M", @"T", @"W", @"T", @"F", @"S", nil];
    for (int i = 0; i < WEEK_DAYS; i++) {
        UILabel *weekDay = [[UILabel alloc] initWithFrame:CGRectMake(i*DAY_WIDTH + WEEK_OFFSET, 0, DAY_WIDTH, DAY_HEIGHT)];
        weekDay.backgroundColor = [UIColor clearColor];
        weekDay.textAlignment = UITextAlignmentCenter;
        if (i == 0 || i == 6) { // change font color for Sunday and Saturday
//            weekDay.textColor = [UIColor colorWithRed:0.5 green:0.5 blue:1.0 alpha:1.0];
            weekDay.textColor = [self getWeekEndColorByIndex:_increment];
        } else {
//            weekDay.textColor = [UIColor whiteColor];
            weekDay.textColor = [self getWeekDayColorByIndex:_increment];
        }
//        weekDay.font = [UIFont fontWithName:@"Courier" size:18.0f]; // Font with the same width
        weekDay.font = [UIFont fontWithName:defaultFont size:18.0f]; // Font with the same width
        weekDay.text = [week_day_titles objectAtIndex:i];
        [cal addSubview:weekDay];
        [weekDay release];
    }
    
    
    int row = 1;
	int col = 0;
	for(int i = 0; i < daysOfMonth; ++i) {
        
        BOOL isFirstLine = TRUE;
        UILabel *dayView = nil;
        if (row == 1) {
            dayView = [[UILabel alloc] initWithFrame:CGRectMake((col + firstWeekDay - 1)*DAY_WIDTH + WEEK_OFFSET, row*DAY_HEIGHT, DAY_WIDTH, DAY_HEIGHT)];
            
            if (i + firstWeekDay == WEEK_DAYS) {
                isFirstLine = FALSE;
            }
            
            if((firstWeekDay == 1 && col == 0) || (firstWeekDay + col == 7)) {
                //NSLog(@"paint blue: %d", i);
//                dayView.textColor = [UIColor colorWithRed:0.5 green:0.5 blue:1.0 alpha:1.0];
                dayView.textColor = [self getWeekEndColorByIndex:_increment];
            } else {
//                dayView.textColor = [UIColor whiteColor];
                dayView.textColor = [self getWeekDayColorByIndex:_increment];
            }
        } else {
            dayView = [[UILabel alloc] initWithFrame:CGRectMake(col*DAY_WIDTH + WEEK_OFFSET, row*DAY_HEIGHT, DAY_WIDTH, DAY_HEIGHT)];
            if (col == 0 || col == 6) { // change font color for sunday and saturday
//                dayView.textColor = [UIColor colorWithRed:0.5 green:0.5 blue:1.0 alpha:1.0];
                dayView.textColor = [self getWeekEndColorByIndex:_increment];
            } else {
//                dayView.textColor = [UIColor whiteColor];
                dayView.textColor = [self getWeekDayColorByIndex:_increment];
            }
        }
        dayView.textAlignment = UITextAlignmentCenter;
        dayView.backgroundColor = [UIColor clearColor];
        
        // set today to red and bigger font
        //        if (IS_TODAY) {
        //            dayView.textColor = [UIColor redColor];
        //            // add a border around the text - QuartzCore/QuartzCore.h
        //            dayView.layer.borderColor = [[UIColor redColor] CGColor];
        //            dayView.layer.borderWidth = 2.0f;            
        //        } else {
        //            dayView.textColor = [UIColor blackColor];
        //        }
//        dayView.font = [UIFont fontWithName:@"Courier" size:21.0f];
        dayView.font = [UIFont fontWithName:defaultFont size:21.0f];
        dayView.text = [NSString stringWithFormat:@"%d", i+1];
        [cal addSubview:dayView];
        [dayView release];
        
        // update column and row index
        if (!isFirstLine || col == WEEK_DAYS - 1) {
            col = 0;
            row ++;
        } else {
            col ++;
        }
	}
    
    // add year text
    UILabel *yearView = [[UILabel alloc] initWithFrame:CGRectMake(0, YEAR_OFFSET_Y, WEEK_OFFSET, YEAR_WIDTH)];
    yearView.backgroundColor = [UIColor clearColor];
//    yearView.textColor = [UIColor cyanColor];
    yearView.textColor = [self getWeekDayColorByIndex:_increment];
//    yearView.font = [UIFont fontWithName:@"Courier" size:25.0f];
    yearView.font = [UIFont fontWithName:defaultFont size:25.0f];
    yearView.text = [NSString stringWithFormat:@"%d", year];
    [cal addSubview:yearView];
    [yearView release];
    
    // add month text
    UILabel *monthView = [[UILabel alloc] initWithFrame:CGRectMake(0, MONTH_OFFSET_Y, WEEK_OFFSET, MONTH_WIDTH)];
    monthView.backgroundColor = [UIColor clearColor];
//    monthView.textColor = [UIColor whiteColor];
    monthView.textColor = [self getWeekEndColorByIndex:_increment];
//    monthView.font = [UIFont fontWithName:@"Courier" size:32.0f]; // Font with the same width
    monthView.font = [UIFont fontWithName:defaultFont size:32.0f]; // Font with the same width
    monthView.text = [self getMonthNameFromNumber:month];
    [cal addSubview:monthView];
    [monthView release];
    
    return [cal autorelease];

}


@end
