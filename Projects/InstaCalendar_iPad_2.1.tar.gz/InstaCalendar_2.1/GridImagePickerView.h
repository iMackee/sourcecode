//  GridImagePickerView.h
//  GalleryCalendar
//
//  Created by User on 11/11/03.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <AssetsLibrary/AssetsLibrary.h>  // TODO delete
#import "MyAssetsLibraryAccessor.h"

@protocol GridImagePickerDelegate

@optional
- (void) onPickedImagesURLs: (NSMutableArray *) imagesURLs;

@end

@interface GridImagePickerView : UIViewController <UIAlertViewDelegate, MyAssetsLibraryThumbnailDelegate> {

    id<GridImagePickerDelegate> _delegate;
    UIScrollView *_scrollView;
    NSMutableArray *_imagesURLs;
    NSMutableArray *_checkedImages;
    UIActivityIndicatorView *_activitIndicator;
    NSDate *_chosenDate;
    
    MyAssetsLibraryAccessor *_myAssetsLibraryAccessor;
    NSInteger _row;
    NSInteger _col;
    NSInteger _counter;  // used for loaded thumbnails
    NSInteger _pickCounter; // used for picked files
    NSInteger _total;
    BOOL _isLibraryEnpty;
    
}

@property (nonatomic, retain) NSMutableArray *imagesURLs;
@property (nonatomic, retain) id<GridImagePickerDelegate> delegate;
@property (nonatomic, retain) UIScrollView *scrollView;
@property (nonatomic, retain) NSDate *chosenDate;
@property (nonatomic, retain) UIActivityIndicatorView *activitIndicator;

@property (nonatomic, retain) NSMutableArray *checkedImages;

/*********************************************
 used for added static images to gird view
- (void)addImage:(UIImage *)image;
 *********************************************/

@end
