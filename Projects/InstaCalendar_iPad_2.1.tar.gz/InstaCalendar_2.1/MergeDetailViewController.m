//
//  MergeDetailViewController.m
//  GalleryCalendar_iPad
//
//  Created by 何 勇 on 11-11-19.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "MergeDetailViewController.h"
#import "PrintPageRenderer.h"

@interface MergeDetailViewController (private)

- (void)printImage: (UIImage *)image;
- (void)mailImage: (UIImage *)image;
- (void)showToolbarAndStatusBar;
- (void)hideToolbarAndStatusBar;

@end

@implementation MergeDetailViewController

@synthesize toolBar=_toolBar;
@synthesize actionBarItem = _actionBarItem;
@synthesize mergeView = _mergeView;
@synthesize image=_image;
@synthesize delegate=_delegate;
@synthesize currentCalendarView=_currentCalendarView;
@synthesize currentImageView=_currentImageView;
@synthesize actionSheet=_actionSheet;
@synthesize printController=_printController;

#pragma mark - private methods

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationNone];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _toolBarHidden = FALSE;
    _isPrintControllerShown = FALSE;
    _currentOrientation = [[UIApplication sharedApplication] statusBarOrientation];
}

- (void)viewDidUnload
{
    //NSLog(@"viewDidUnload");
    [self setToolBar:nil];
    [self setImage:nil];
    [self setCurrentCalendarView:nil];
    [self setCurrentImageView:nil];
    [self setActionBarItem:nil];
    [self setMergeView:nil];
    [self setPrintController:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    // return (interfaceOrientation == UIInterfaceOrientationPortrait);
    return YES;
}


- (void) willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
//    NSLog(@"willRotateToInterfaceOrientation: %d", toInterfaceOrientation);
    _currentOrientation = toInterfaceOrientation;
    CGRect scrBound = [[UIScreen mainScreen] bounds];
    CGFloat scrWidth = scrBound.size.width;
    CGFloat scrHeight = scrBound.size.height;
    if (UIDeviceOrientationIsLandscape(toInterfaceOrientation)) {
        self.currentImageView.center = CGPointMake(scrHeight/2, scrWidth/2);
        self.currentCalendarView.center = CGPointMake(scrHeight/2, scrWidth/2);
    } else {
        self.currentImageView.center = CGPointMake(scrWidth/2, scrHeight/2);
        self.currentCalendarView.center = CGPointMake(scrWidth/2, scrHeight/2);
    }    
}


// tool bar action
- (IBAction)cancelMerge:(id)sender {
    if (_isPrintControllerShown) {
        _isPrintControllerShown = FALSE;
        [_printController dismissAnimated:YES];
    }
    if ([_actionSheet isVisible]) {
        [_actionSheet dismissWithClickedButtonIndex:[_actionSheet cancelButtonIndex] animated:YES];
    }
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationNone];
    [self dismissModalViewControllerAnimated:YES];
}



- (IBAction)previewMerge:(id)sender {
    if (_isPrintControllerShown) {
        _isPrintControllerShown = FALSE;
        [_printController dismissAnimated:YES];
    }
    if (_actionSheet != nil && [_actionSheet isVisible]) {
        [_actionSheet dismissWithClickedButtonIndex:[_actionSheet cancelButtonIndex] animated:YES];
    }
    self.toolBar.hidden = TRUE;
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
    _toolBarHidden = TRUE;
}


- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == [actionSheet cancelButtonIndex]) return;
}

- (IBAction)confirmMerge:(id)sender {

    if (_isPrintControllerShown) {
        _isPrintControllerShown = FALSE;
        [_printController dismissAnimated:YES];
    }
    // to avoid the app to freeze when action sheet is shown and tap cancel button
    if (_actionSheet != nil && [_actionSheet isVisible]) {
        [_actionSheet dismissWithClickedButtonIndex:[_actionSheet cancelButtonIndex] animated:YES];
        return;
    }
    if ([[[UIDevice currentDevice] systemVersion] floatValue] < 5.0) {
        _actionSheet = [[UIActionSheet alloc] initWithTitle:@"Share options" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Save to library" otherButtonTitles:@"Print", @"Mail", nil];        
        _actionSheet.destructiveButtonIndex = 3; // make the cancel button red
    } else {
        // add twitter share
        _actionSheet = [[UIActionSheet alloc] initWithTitle:@"Share options" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Save to library" otherButtonTitles:@"Print", @"Mail", @"Twitter", nil];
        _actionSheet.destructiveButtonIndex = 4; // make the cancel button red
    }
    _actionSheet.actionSheetStyle = UIActionSheetStyleDefault;
    _actionSheet.tag = 1;
    [_actionSheet showFromBarButtonItem:self.actionBarItem animated:YES];
}

#pragma mark - UIActionSheetDelegate method
- (void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //NSLog(@"click at index: %d", buttonIndex);
    UIImage *image;
    CGRect screenBound = [[UIScreen mainScreen] bounds];
    switch (buttonIndex) {
        case 0:  // save
//            NSLog(@"save");
            
            // Before saving the image, hide toolbar and status bar
            [self hideToolbarAndStatusBar];
            
            if (UIDeviceOrientationIsLandscape(_currentOrientation)) {
//                NSLog(@"Device in landscape");
                //NSLog(@"width: %f, height: %f", sz.width, sz.height);
                UIGraphicsBeginImageContextWithOptions(CGSizeMake(screenBound.size.height, screenBound.size.width), self.view.opaque, [[UIScreen mainScreen] scale]);
                [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                image = UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
            } else {
                UIGraphicsBeginImageContextWithOptions(screenBound.size, self.view.opaque, [[UIScreen mainScreen] scale]);
                [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                image = UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
            }
            
            UIImageWriteToSavedPhotosAlbum(image, self, @selector(savedImage:didFinishSavingWithError:contextInfo:), nil);
            
            // After saving the image, show toolbar and status bar            
            [self showToolbarAndStatusBar];
            
            // stay in the merge detail view.
            //[self dismissModalViewControllerAnimated:YES];
            break;
            
        case 1:  // print
//            NSLog(@"print");
            // Before saving the image, hide toolbar
            self.toolBar.hidden = TRUE;
            
            if (UIDeviceOrientationIsLandscape(_currentOrientation)) {
//                NSLog(@"Device in landscape");
                //NSLog(@"width: %f, height: %f", sz.width, sz.height);
                UIGraphicsBeginImageContextWithOptions(CGSizeMake(screenBound.size.height, screenBound.size.width), self.view.opaque, [[UIScreen mainScreen] scale]);
                [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                image = UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
            } else {
                UIGraphicsBeginImageContextWithOptions(screenBound.size, self.view.opaque, [[UIScreen mainScreen] scale]);
                [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                image = UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
            }
            [self printImage:image];
            
            // After saving the image, show toolbar
            self.toolBar.hidden = FALSE;
            
            // after print, stay in the current view
            //[self dismissModalViewControllerAnimated:YES];
            break;
            
        case 2:  // mail
//            NSLog(@"mail");
            if(![MFMailComposeViewController canSendMail]) {
                UIAlertView *error = [[UIAlertView alloc] initWithTitle:@"Error" message:@"The mail account is not properly set up or mailing function is not supported!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                [error show];
                [error release];
                return;
            }
            // Before saving the image, hide toolbar
            self.toolBar.hidden = TRUE;
            
            if (UIDeviceOrientationIsLandscape(_currentOrientation)) {
//                NSLog(@"Device in landscape");
                //NSLog(@"width: %f, height: %f", sz.width, sz.height);
                UIGraphicsBeginImageContextWithOptions(CGSizeMake(screenBound.size.height, screenBound.size.width), self.view.opaque, [[UIScreen mainScreen] scale]);
                [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                image = UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
            } else {
                UIGraphicsBeginImageContextWithOptions(screenBound.size, self.view.opaque, [[UIScreen mainScreen] scale]);
                [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                image = UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
            }
            [self mailImage:image];
            
            // After saving the image, show toolbar
            self.toolBar.hidden = FALSE;
            
            // after mail, stay in the current view
            //[self dismissModalViewControllerAnimated:YES];
            break;
            
        case 3: // cancel or twitter start from iOS 5.0
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 5.0) {
                
                if (![TWTweetComposeViewController canSendTweet]) {
                    UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Sorry, the Twitter function is not available, you may check your setting or network status and try again." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                    [av show];
                    [av release];
                    return;
                }
                // Before saving the image, hide toolbar
                self.toolBar.hidden = TRUE;
                
                if (UIDeviceOrientationIsLandscape(_currentOrientation)) {
//                    NSLog(@"Device in landscape");
                    //NSLog(@"width: %f, height: %f", sz.width, sz.height);
                    UIGraphicsBeginImageContextWithOptions(CGSizeMake(screenBound.size.height, screenBound.size.width), self.view.opaque, [[UIScreen mainScreen] scale]);
                    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                    image = UIGraphicsGetImageFromCurrentImageContext();
                    UIGraphicsEndImageContext();
                } else {
                    UIGraphicsBeginImageContextWithOptions(screenBound.size, self.view.opaque, [[UIScreen mainScreen] scale]);
                    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                    image = UIGraphicsGetImageFromCurrentImageContext();
                    UIGraphicsEndImageContext();
                }
                
                // After saving the image, show toolbar
                self.toolBar.hidden = FALSE;
                
                // twitter
                TWTweetComposeViewController *twitter = [[TWTweetComposeViewController alloc] init];
                [twitter setInitialText:[NSString stringWithFormat:@"Created with InstaCalendar(%d/%d)", _currentYear, _currentMonth]];
//                [twitter setInitialText:[NSString stringWithFormat:@"Calendar of %d/%d", _currentYear, _currentMonth]];
                [twitter addImage:image];
                twitter.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
                [self presentModalViewController:twitter animated:YES];
                
                __block UIAlertView *twav = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Published to twitter." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                twitter.completionHandler = ^(TWTweetComposeViewControllerResult result) {
                    switch (result)
                    {
                        case TWTweetComposeViewControllerResultCancelled:
                            // cancel button clicked
                            //[twav setTitle:@"Canceled publishing to twitter."];
                            //[twav show];
                            [twav release];
                            break;
                        case TWTweetComposeViewControllerResultDone:
                            [twav setTitle:@"Published to twitter."];
                            [twav show];
                            [twav release];
                            break;
                        default:
                            [twav release];
                            break;
                    }
                    // maybe a bug, but the line below must be called, 
                    // or any operation is disabled.
                    [self dismissModalViewControllerAnimated:YES];
                };
                [twitter release];
            }
            break;
            
        default:
            break;
    }
}


#pragma mark - share - print
- (void)printImage: (UIImage *) image
{
    // Obtain the shared UIPrintInteractionController
    _printController = [UIPrintInteractionController sharedPrintController];
    if(!_printController){
        UIAlertView *error = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Couldn't get shared UIPrintInteractionController!"  delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [error show];
        [error release];        
        return;
    }
    
    // We need a completion handler block for printing.
    UIPrintInteractionCompletionHandler completionHandler = ^(UIPrintInteractionController *printController, BOOL completed, NSError *error) {
        if(completed && error)
            NSLog(@"FAILED! due to error in domain %@ with error code %u", error.domain, error.code);
    };
    
    // Obtain a printInfo so that we can set our printing defaults.
    UIPrintInfo *printInfo = [UIPrintInfo printInfo];
    
    // This application prints photos. UIKit will pick a paper size and print
    // quality appropriate for this content type.
    printInfo.outputType = UIPrintInfoOutputPhoto;
    
    // The path to the image may or may not be a good name for our print job
    // but that's all we've got.
    //    printInfo.jobName = [[self.imageURL path] lastPathComponent];
    
    // If we are performing drawing of our image for printing we will print
    // landscape photos in a landscape orientation.
    if(!_printController.printingItem && image.size.width > image.size.height)
        printInfo.orientation = UIPrintInfoOrientationLandscape;
    
    // Use this printInfo for this print job.
    _printController.printInfo = printInfo;
    
    //  Since the code below relies on printingItem being zero if it hasn't
    //  already been set, this code sets it to nil. 
    _printController.printingItem = nil;
    
    
    PrintPageRenderer *ppr = [[PrintPageRenderer alloc] init];
    ppr.imageToPrint = image;
    _printController.printPageRenderer = ppr;
    [ppr release];
    
    // The method we use presenting the printing UI depends on the type of 
    // UI idiom that is currently executing. Once we invoke one of these methods
    // to present the printing UI, our application's direct involvement in printing
    // is complete. Our delegate methods (if any) and page renderer methods (if any)
    // are invoked by UIKit.
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        [_printController presentFromBarButtonItem:self.actionBarItem animated:YES completionHandler:completionHandler];  // iPad
        _isPrintControllerShown = TRUE;
    }else {
        [_printController presentAnimated:YES completionHandler:completionHandler];  // iPhone
    }
}



#pragma mark - mail
- (void) mailImage:(UIImage *)image
{
    MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
    mailController.mailComposeDelegate = self;
    mailController.toolbar.barStyle = UIBarStyleBlackTranslucent;
    [mailController setSubject:@"Instant Calendar"];
    [mailController setMessageBody:[NSString stringWithFormat:@"Hi, I'd like to share the image calender of (%d/%d) with you:-)", _currentYear, _currentMonth] isHTML:NO];
    [mailController addAttachmentData:UIImagePNGRepresentation(image) mimeType:@"image/png" fileName:[NSString stringWithFormat:@"InstaCalendar_%d_%d.png", _currentYear, _currentMonth]];
    
    [self presentModalViewController:mailController animated:YES];
    [mailController release];
}


#pragma mark - MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
//    NSLog(@"mailComposeController");
    
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Information" message:@"Sending" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    
    switch (result)
    {
        case MFMailComposeResultCancelled:
            break;
        case MFMailComposeResultSaved:
            break;
        case MFMailComposeResultSent:
            message.title = @"Success";
            message.message = @"Mail sent successfully.";
            [message show];
            break;
        case MFMailComposeResultFailed:
            message.title = @"Error";
            message.message = @"Failure, mail not sent.";
            [message show];
            break;
        default:
            break;
    }
    [message release];
    // restore the device orientation
    _currentOrientation = [[UIApplication sharedApplication] statusBarOrientation];
    [self dismissModalViewControllerAnimated:YES];
}

-(void)showToolbarAndStatusBar
{
    self.toolBar.hidden = FALSE;
//    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationNone];
}

-(void)hideToolbarAndStatusBar
{
    self.toolBar.hidden = TRUE;
//    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationNone];
}


#pragma mark - UIImageWriteToSavedPhotosAlbum selector method
- (void) savedImage: (UIImage *)image didFinishSavingWithError: (NSError *)error contextInfo: (void *)contextInfo
{
    if (error) {
        UIAlertView *error = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Saving image failed! Make sure there is space for saving images!" delegate:nil cancelButtonTitle:@"Confirm" otherButtonTitles:nil];
        [error show];
        [error release];
    } else {
        UIAlertView *info = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Saved to camera roll." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [info show];
        [info release];
    }
}

// public methods
- (void)presentImage: (UIImage *)image
{
    if (self.currentImageView) {
        [self.currentImageView removeFromSuperview];
    }
    self.image = image;
    self.currentImageView = [[[UIImageView alloc] initWithImage:image] autorelease];
    self.currentImageView.center = self.view.center;
    
    // add a move gesture recognizer
    self.currentImageView.userInteractionEnabled = YES;
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(imageMoved:)];
    [self.currentImageView addGestureRecognizer:panGesture];
    [panGesture release];
    
    // pinch gesture
    UIPinchGestureRecognizer *pinchGesture = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchAction:)];
    [self.currentImageView addGestureRecognizer:pinchGesture];
    [pinchGesture release];
    
    // tap gesture
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    tapGesture.numberOfTouchesRequired = 1;
    tapGesture.numberOfTapsRequired = 1;
//    [self.currentImageView addGestureRecognizer:tapGesture];
    [self.mergeView addGestureRecognizer:tapGesture];
    [tapGesture release];
    
//    [self.view addSubview:self.currentImageView];
    [self.mergeView addSubview:self.currentImageView];
}

- (void)presentCalendar: (UIView *)calendar
{
    // keep a copy
    self.currentCalendarView = [NSKeyedUnarchiver unarchiveObjectWithData:[NSKeyedArchiver archivedDataWithRootObject:calendar]];
    
    // add a rotation gesture recognizer
    UIRotationGestureRecognizer *rotationGesture = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(calendarRotated:)];  
    [self.view addGestureRecognizer:rotationGesture];  
    [rotationGesture release];  
    
    // add a move gesture recognizer
    self.currentCalendarView.userInteractionEnabled = YES;
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(calendarMoved:)];
    [self.currentCalendarView addGestureRecognizer:panGesture];
    [panGesture release];
    
    // pinch gesture
    UIPinchGestureRecognizer *pinchGesture = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchCalAction:)];
    [self.currentCalendarView addGestureRecognizer:pinchGesture];
    [pinchGesture release];
    
//    [self.view addSubview:self.currentCalendarView];
    [self.mergeView addSubview:self.currentCalendarView];
}


- (void)setSeletedYear: (NSInteger)year month: (NSInteger)month
{
    _currentYear = year;
    _currentMonth = month;
}

#pragma mark - UIRotationGestureRecognizer
//rotate the calendar image view
- (void)calendarRotated:(UIRotationGestureRecognizer *)recognizer
{
    CGAffineTransform trans = CGAffineTransformMakeRotation(recognizer.rotation);
    self.currentCalendarView.transform =  trans;
}

#pragma mark - UIPanGestureRecognizer
//move the calendar image view
- (void)calendarMoved:(UIPanGestureRecognizer *)recognizer
{
    //NSLog(@"calendar image moved");
    if ((recognizer.state == UIGestureRecognizerStateChanged) || (recognizer.state == UIGestureRecognizerStateEnded)) {	
        // get the distance moved
        CGPoint movedTo = [recognizer translationInView:self.view];
        // get the original center
        CGPoint center = self.currentCalendarView.center;
        // compute new center
        center.x = center.x + movedTo.x;
        center.y = center.y + movedTo.y;
        // set new center to move image
        self.currentCalendarView.center = center;
        // reset transition
        [recognizer setTranslation:CGPointZero inView:self.view];
    }
}

//move the image view
- (void)imageMoved:(UIPanGestureRecognizer *)recognizer
{
    //NSLog(@"image moved");
    if ((recognizer.state == UIGestureRecognizerStateChanged) || (recognizer.state == UIGestureRecognizerStateEnded)) {	
        // get the distance moved
        CGPoint movedTo = [recognizer translationInView:self.view];
        // get the original center
        CGPoint center = self.currentImageView.center;
        // compute new center
        center.x = center.x + movedTo.x;
        center.y = center.y + movedTo.y;
        // set new center to move image
        self.currentImageView.center = center;
        // reset transition
        [recognizer setTranslation:CGPointZero inView:self.view];
    }
}


// pinch gesture reactor
-(void)pinchAction: (UIPinchGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateBegan) {
        currentTransform = self.currentImageView.transform;
    }
    CGFloat scale = [sender scale];
    self.currentImageView.transform = CGAffineTransformConcat(currentTransform, CGAffineTransformMakeScale(scale, scale));
}


-(void)pinchCalAction: (UIPinchGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateBegan) {
        currentTransform = self.currentCalendarView.transform;
    }
    CGFloat scale = [sender scale];
    
    self.currentCalendarView.transform = CGAffineTransformConcat(currentTransform, CGAffineTransformMakeScale(scale, scale));
}


// tap gesture reactor 
- (void) tapAction: (UITapGestureRecognizer *)sender
{
    //NSLog(@"tapAction");
    self.toolBar.hidden = !_toolBarHidden;
    if (!_toolBarHidden) {
        [self.navigationController setToolbarHidden:YES animated:YES];
        [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationFade];
    } else {
        [self.navigationController setToolbarHidden:FALSE animated:YES];
        [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationSlide];
    }
    _toolBarHidden = !_toolBarHidden;
}


- (void)dealloc {
    [_toolBar release];
    [_actionBarItem release];
    [_image release];
    [_delegate release];
    [_currentCalendarView release];
    [_currentImageView release];
    [_mergeView release];
    [_printController release];
    [super dealloc];
}
@end