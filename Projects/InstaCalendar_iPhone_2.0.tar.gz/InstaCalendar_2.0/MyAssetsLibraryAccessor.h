//
//  MyAssetsLibraryAccessor.h
//  GalleryCalendar
//
//  Created by User on 11/11/14.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AssetsLibrary/AssetsLibrary.h>

@protocol MyAssetsLibraryThumbnailDelegate <NSObject>

@optional
-(void)onGetThumbnail: (UIImage *) thumbnail withIndex: (NSInteger) index;

-(void)onGetFullSizeImage: (UIImage *) image;

@end


@interface MyAssetsLibraryAccessor : NSObject {
@private
    ALAssetsLibrary *_assetsLibrary;
    id<MyAssetsLibraryThumbnailDelegate> _delegate;
}

@property (nonatomic, retain) id<MyAssetsLibraryThumbnailDelegate> delegate;

- (void)loadURLsWithCBTarget:(id)target
                    andCBMethod:(SEL)cbSelector;
- (NSDictionary *)getMetadataByUrl:(NSURL *)url;
// synchronous
//- (UIImage *)getThumbnailOfAssetsByURL:(NSURL *)url;
//- (UIImage *)getFullResolutionImageByURL:(NSURL *)url;
// asynchrouns
- (void)getThumbnailOfAssetsWithCBByURL:(NSURL *)url andIndex: (NSInteger)index;
- (void)getFullResolutionImageWithCBByURL:(NSURL *)url; // may have memory problem, not use
- (void)getFullScreenImageWithCBByURL:(NSURL *)url;


// test method
//- (void)enumerationTest;


@end
