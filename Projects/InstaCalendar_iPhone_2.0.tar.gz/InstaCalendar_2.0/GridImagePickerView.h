//  GridImagePickerView.h
//  GalleryCalendar
//
//  Created by User on 11/11/03.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <AssetsLibrary/AssetsLibrary.h>  // TODO delete
#import "MyAssetsLibraryAccessor.h"

@protocol GridImagePickerDelegate

@optional
- (void) onPickedImagesURLs: (NSMutableArray *) imagesURLs;

@end

@interface GridImagePickerView : UIViewController <UIAlertViewDelegate, MyAssetsLibraryThumbnailDelegate> {

//	UIImage *_selectedImage;
    id<GridImagePickerDelegate> _delegate;
    UIScrollView *_scrollView;
    
    NSMutableArray *_imagesURLs;
    NSMutableArray *_checkedImages;
    
//    ALAssetsLibrary *_assetsLibrary;
    UIActivityIndicatorView *_activitIndicator;
    
    MyAssetsLibraryAccessor *_myAssetsLibraryAccessor;
    
    NSDate *_chosenDate;
    
    NSInteger _row;
    NSInteger _col;
    NSInteger _counter;  // used for loaded thumbnails
    NSInteger _pickCounter; // used for picked files
    NSInteger _total;
    BOOL _isLibraryEnpty;
    
}

@property (nonatomic, retain) NSMutableArray *imagesURLs;
//@property (nonatomic, retain) UIImage *selectedImage;
@property (nonatomic, retain) id<GridImagePickerDelegate> delegate;
@property (nonatomic, retain) UIScrollView *scrollView;
@property (nonatomic, retain) NSDate *chosenDate;
@property (nonatomic, retain) UIActivityIndicatorView *activitIndicator;

@property (nonatomic, retain) NSMutableArray *checkedImages;
//@property (nonatomic, retain) ALAssetsLibrary *assetsLibrary;

/*********************************************
 used for added static images to gird view
- (void)addImage:(UIImage *)image;
 *********************************************/

@end
