//
//  PreviewOneMonthView.m
//  InstaCalendar
//
//  Created by 何 勇 on 11-12-2.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "PreviewOneMonthView.h"

@interface PreviewOneMonthView (private)

- (void)addGestureRecognizerToCalendarView;
- (void)redrawCalendar;
- (void)printImage: (UIImage *)image;
- (void)mailImage: (UIImage *)image;
- (void)showToolBar;
- (void)hideToolBar;
- (void)showImagePicker;

@end

@implementation PreviewOneMonthView
@synthesize upperToolBar = _upperToolBar;
@synthesize lowerToolBar = _lowerToolBar;
@synthesize dateText;
@synthesize previewButton = _previewButton;
@synthesize actionButton = _actionButton;
@synthesize imageView;
@synthesize mainView = _mainView;
//@synthesize currImage=_currImage;
@synthesize currentCalendarView=_currentCalendarView;

#define ACTION_SHEET_TITLE_CHOOSE @"Choose Image Source"
#define ACTION_SHEET_TITLE_SHARE  @"Share Options"

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationNone];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _toolBarHidden = FALSE;
    _currentOrientation = [[UIApplication sharedApplication] statusBarOrientation];
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] init];
    singleTap.numberOfTapsRequired = 1;
    singleTap.numberOfTouchesRequired = 1;
    [singleTap addTarget:self action:@selector(mainViewTaped:)];
    [self.mainView addGestureRecognizer:singleTap];
    [singleTap release];
    
//    [imageView setImage:_currImage];
    // add a move gesture recognizer
    self.imageView.userInteractionEnabled = YES;
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(imageMoved:)];
    [self.imageView addGestureRecognizer:panGesture];
    [panGesture release];
    
    // pinch gesture
    UIPinchGestureRecognizer *pinchGesture = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchAction:)];
    [self.imageView addGestureRecognizer:pinchGesture];
    [pinchGesture release];

    
    
    NSDateComponents *comp = [[NSCalendar currentCalendar] components: NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate: [NSDate date]];
    _currentMonth = [comp month];
    _currentYear = [comp year];
    NSString *s = [NSString stringWithFormat:@"%d - %d", _currentYear, _currentMonth];
    self.dateText.title = s;
    
    // draw calendar
    
    
    UIView *view = [CalendarImageView makeCalendarWithYear:_currentYear andMonth:_currentMonth];
    view.tag = _currentMonth;
    self.currentCalendarView = view;
    savedCalTransform = view.transform;
    savedCalCenter = view.center;
    [self addGestureRecognizerToCalendarView];
    [self.mainView addSubview:view];
    
    // before choosing pictures, hide the preview and action button
    [self.previewButton setEnabled:FALSE];
    [self.actionButton setEnabled:FALSE];
}

- (void)viewDidUnload
{
    [self setImageView:nil];
//    [self setCurrImage:nil];
    [self setDateText:nil];
    [self setUpperToolBar:nil];
    [self setLowerToolBar:nil];
    [self setCurrentCalendarView:nil];
    [self setMainView:nil];
    [self setPreviewButton:nil];
    [self setActionButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
//    return (interfaceOrientation == UIInterfaceOrientationPortrait);
    return YES;
}

- (void)dealloc {
    [imageView release];
//    [_currImage release];
    [dateText release];
    [_upperToolBar release];
    [_lowerToolBar release];
    [_currentCalendarView release];
    [_mainView release];
    [_previewButton release];
    [_actionButton release];
    [super dealloc];
}


- (void)addGestureRecognizerToCalendarView
{
    self.currentCalendarView.userInteractionEnabled = TRUE;
    // add a rotation gesture recognizer
    UIRotationGestureRecognizer *rotationGesture = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(calendarRotated:)];  
    [self.currentCalendarView addGestureRecognizer:rotationGesture];  
    [rotationGesture release];  
    
    // add a move gesture recognizer
    self.currentCalendarView.userInteractionEnabled = YES;
    UIPanGestureRecognizer *calPanGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(calendarMoved:)];
    [self.currentCalendarView addGestureRecognizer:calPanGesture];
    [calPanGesture release];
}

// @selector
- (void) mainViewTaped: (UIView *) sender
{
    if (_toolBarHidden) {
        self.upperToolBar.hidden = FALSE;
        self.lowerToolBar.hidden = FALSE;
        _toolBarHidden = FALSE;
    } else {
        NSInteger count = [self.mainView.subviews count];
        for (int i = 0; i < count; i++) {
            UIView *cal = [self.mainView.subviews objectAtIndex:i];
            NSInteger tag = cal.tag;
            if (tag >= 1) {
                [cal removeFromSuperview];
            } 
        }
        
        UIView *cal = nil;
        cal = [CalendarImageView changeCalendarColorWithYear:_currentYear andMonth:_currentMonth];
        cal.tag = _currentMonth;
        cal.transform = savedCalTransform;
        cal.center = savedCalCenter;
        self.currentCalendarView = cal;
        [self addGestureRecognizerToCalendarView];
        [self.mainView addSubview:cal];
    }
}


//move the image view
- (void)imageMoved:(UIPanGestureRecognizer *)recognizer
{
    //NSLog(@"image moved");
    if ((recognizer.state == UIGestureRecognizerStateChanged) || (recognizer.state == UIGestureRecognizerStateEnded)) {	
        // get the distance moved
        CGPoint movedTo = [recognizer translationInView:self.view];
        // get the original center
        CGPoint center = self.imageView.center;
        // compute new center
        center.x = center.x + movedTo.x;
        center.y = center.y + movedTo.y;
        // set new center to move image
        self.imageView.center = center;
        // reset transition
        [recognizer setTranslation:CGPointZero inView:self.view];
    }
}


// pinch gesture reactor
-(void)pinchAction: (UIPinchGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateBegan) {
        currentTransform = self.imageView.transform;
    }
    CGFloat scale = [sender scale];
    self.imageView.transform = CGAffineTransformConcat(currentTransform, CGAffineTransformMakeScale(scale, scale));
}


#pragma mark - UIRotationGestureRecognizer
//rotate the calendar image view
- (void)calendarRotated:(UIRotationGestureRecognizer *)recognizer
{
    CGAffineTransform trans = CGAffineTransformMakeRotation(recognizer.rotation);
    self.currentCalendarView.transform =  trans;
    savedCalTransform = trans;
}

#pragma mark - UIPanGestureRecognizer
//move the calendar image view
- (void)calendarMoved:(UIPanGestureRecognizer *)recognizer
{
    //NSLog(@"calendar image moved");
    if ((recognizer.state == UIGestureRecognizerStateChanged) || (recognizer.state == UIGestureRecognizerStateEnded)) {	
        // get the distance moved
        CGPoint movedTo = [recognizer translationInView:self.view];
        // get the original center
        CGPoint center = self.currentCalendarView.center;
        // compute new center
        center.x = center.x + movedTo.x;
        center.y = center.y + movedTo.y;
        // set new center to move image
        self.currentCalendarView.center = center;
        savedCalCenter = center;
        // reset transition
        [recognizer setTranslation:CGPointZero inView:self.view];
    }
}

- (void)redrawCalendar
{
    NSInteger count = [self.mainView.subviews count];
    for (int i = 0; i < count; i++) {
        UIView *cal = [self.mainView.subviews objectAtIndex:i];
        NSInteger tag = cal.tag;
        if (tag >= 1) {
            [cal removeFromSuperview];
        } 
    }
    
    UIView *cal = nil;
    cal = [CalendarImageView makeCalendarWithYear:_currentYear andMonth:_currentMonth];
    cal.tag = _currentMonth;
    cal.transform = savedCalTransform;
    cal.center = savedCalCenter;
    self.currentCalendarView = cal;
    [self addGestureRecognizerToCalendarView];
    [self.mainView addSubview:cal];
}


- (IBAction)nextMonth:(id)sender {
    if (12 == _currentMonth) {
        _currentYear++;
        _currentMonth = 1;
    } else {
        _currentMonth++;
    }
    NSString *s = [NSString stringWithFormat:@"%d - %d", _currentYear, _currentMonth];
    self.dateText.title = s;
    
    [self redrawCalendar];
}

- (IBAction)prevMonth:(id)sender {
    if (1 == _currentMonth) {
        _currentYear--;
        _currentMonth = 12;
    } else {
        _currentMonth--;
    }
    NSString *s = [NSString stringWithFormat:@"%d - %d", _currentYear, _currentMonth];
    self.dateText.title = s;
    
    [self redrawCalendar];
}

- (IBAction)done:(id)sender {
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationNone];
    [self dismissModalViewControllerAnimated:YES];
}

- (IBAction)preview:(id)sender {
    self.upperToolBar.hidden = TRUE;
    self.lowerToolBar.hidden = TRUE;
    _toolBarHidden = TRUE;
}

- (IBAction)action:(id)sender {
    UIActionSheet *actionSheet = nil;
    if ([[[UIDevice currentDevice] systemVersion] floatValue] < 5.0) {
        actionSheet = [[UIActionSheet alloc] initWithTitle:ACTION_SHEET_TITLE_SHARE delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Save to library" otherButtonTitles:@"Print", @"Mail", nil];
        actionSheet.actionSheetStyle = UIActionSheetStyleDefault;
        actionSheet.tag = 1;
        actionSheet.destructiveButtonIndex = 3; // make the cancel button red
        [actionSheet showInView:self.view];     // Show in current view
        [actionSheet release];
    } else {
        // add twitter share
        actionSheet = [[UIActionSheet alloc] initWithTitle:ACTION_SHEET_TITLE_SHARE delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Save to library" otherButtonTitles:@"Print", @"Mail", @"Twitter", nil];
        actionSheet.actionSheetStyle = UIActionSheetStyleDefault;
        actionSheet.tag = 1;
        actionSheet.destructiveButtonIndex = 4; // make the cancel button red
        [actionSheet showInView:self.view];     // Show in current view
        [actionSheet release];
        
    }

}

- (IBAction)pickImage:(id)sender {
    // Open a popup dialog for picking picture
    UIActionSheet *actionSheet = nil;
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        actionSheet = [[UIActionSheet alloc] initWithTitle:ACTION_SHEET_TITLE_CHOOSE
                                                  delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Library" otherButtonTitles:@"Camera", nil];
        actionSheet.destructiveButtonIndex = 2; // make the cancel button red
    } else {
        actionSheet = [[UIActionSheet alloc] initWithTitle:ACTION_SHEET_TITLE_CHOOSE
                                    delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Library" otherButtonTitles:nil];
        actionSheet.destructiveButtonIndex = 1; // make the cancel button red
    }
    actionSheet.actionSheetStyle = UIActionSheetStyleDefault;
    actionSheet.tag = 1;
        [actionSheet showInView:self.view];     // Show in current view
    [actionSheet release];
}

//- (void) setImage: (UIImage *) image
//{
//    _currImage = image;
//    
//}

- (void) willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
//    NSLog(@"willRotateToInterfaceOrientation: %d", toInterfaceOrientation);
    _currentOrientation = toInterfaceOrientation;
    CGRect scrBound = [[UIScreen mainScreen] bounds];
    CGFloat scrWidth = scrBound.size.width;
    CGFloat scrHeight = scrBound.size.height;
    if (UIDeviceOrientationIsLandscape(toInterfaceOrientation)) {
        self.imageView.center = CGPointMake(scrHeight/2, scrWidth/2);
        self.currentCalendarView.center = CGPointMake(scrHeight/2, scrWidth/2);
    } else {
        self.imageView.center = CGPointMake(scrWidth/2, scrHeight/2);
        self.currentCalendarView.center = CGPointMake(scrWidth/2, scrHeight/2);
    }    
}


#pragma mark - UIActionSheetDelegate method
- (void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //NSLog(@"click at index: %d", buttonIndex);
    if(actionSheet.title == ACTION_SHEET_TITLE_CHOOSE) {
        switch (buttonIndex) {
            case 0:
//                NSLog(@"Choose from gallery");
                [self showImagePicker];
                break;
                
            case 1:
//                NSLog(@"Take a photo from camera");
                if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
                {
                    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                    imagePicker.delegate = self;
                    imagePicker.allowsEditing = NO;	
                    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                    imagePicker.showsCameraControls = YES;
                    [self presentModalViewController:imagePicker animated: YES];
                    [imagePicker release];
                }
                break;
                
            default:
                break;
        }

    } else if (actionSheet.title == ACTION_SHEET_TITLE_SHARE) {
        UIImage *image;
        CGRect screenBound = [[UIScreen mainScreen] bounds];
        switch (buttonIndex) {
            case 0:  // save
//                NSLog(@"save");
                
                // Before saving the image, hide toolbar and status bar
                [self hideToolBar];
                
                if (UIDeviceOrientationIsLandscape(_currentOrientation)) {
//                    NSLog(@"Device in landscape");
                    //NSLog(@"width: %f, height: %f", sz.width, sz.height);
                    UIGraphicsBeginImageContextWithOptions(CGSizeMake(screenBound.size.height, screenBound.size.width), self.view.opaque, [[UIScreen mainScreen] scale]);
                    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                    image = UIGraphicsGetImageFromCurrentImageContext();
                    UIGraphicsEndImageContext();
                } else {
                    UIGraphicsBeginImageContextWithOptions(screenBound.size, self.view.opaque, [[UIScreen mainScreen] scale]);
                    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                    image = UIGraphicsGetImageFromCurrentImageContext();
                    UIGraphicsEndImageContext();
                }
                
                UIImageWriteToSavedPhotosAlbum(image, self, @selector(savedImage:didFinishSavingWithError:contextInfo:), nil);
                
                // After saving the image, show toolbar and status bar            
                [self showToolBar];
                
                // stay in the merge detail view.
                //[self dismissModalViewControllerAnimated:YES];
                break;
                
            case 1:  // print
//                NSLog(@"print");
                // Before saving the image, hide toolbar
                [self hideToolBar];
                
                if (UIDeviceOrientationIsLandscape(_currentOrientation)) {
//                    NSLog(@"Device in landscape");
                    //NSLog(@"width: %f, height: %f", sz.width, sz.height);
                    UIGraphicsBeginImageContextWithOptions(CGSizeMake(screenBound.size.height, screenBound.size.width), self.view.opaque, [[UIScreen mainScreen] scale]);
                    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                    image = UIGraphicsGetImageFromCurrentImageContext();
                    UIGraphicsEndImageContext();
                } else {
                    UIGraphicsBeginImageContextWithOptions(screenBound.size, self.view.opaque, [[UIScreen mainScreen] scale]);
                    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                    image = UIGraphicsGetImageFromCurrentImageContext();
                    UIGraphicsEndImageContext();
                }
                [self printImage:image];
                
                // After saving the image, show toolbar
                [self showToolBar];
                
                // after print, stay in the current view
                //[self dismissModalViewControllerAnimated:YES];
                break;
                
            case 2:  // mail
//                NSLog(@"mail");
                if(![MFMailComposeViewController canSendMail]) {
                    UIAlertView *error = [[UIAlertView alloc] initWithTitle:@"Error" message:@"The mail account is not properly set up or mailing function is not supported!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                    [error show];
                    [error release];
                    return;
                }
                // Before saving the image, hide toolbar
                [self hideToolBar];
                
                if (UIDeviceOrientationIsLandscape(_currentOrientation)) {
//                    NSLog(@"Device in landscape");
                    //NSLog(@"width: %f, height: %f", sz.width, sz.height);
                    UIGraphicsBeginImageContextWithOptions(CGSizeMake(screenBound.size.height, screenBound.size.width), self.view.opaque, [[UIScreen mainScreen] scale]);
                    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                    image = UIGraphicsGetImageFromCurrentImageContext();
                    UIGraphicsEndImageContext();
                } else {
                    UIGraphicsBeginImageContextWithOptions(screenBound.size, self.view.opaque, [[UIScreen mainScreen] scale]);
                    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                    image = UIGraphicsGetImageFromCurrentImageContext();
                    UIGraphicsEndImageContext();
                }
                [self mailImage:image];
                
                // After saving the image, show toolbar
                [self showToolBar];
                
                // after mail, stay in the current view
                //[self dismissModalViewControllerAnimated:YES];
                break;
                
            case 3: // cancel or twitter start from iOS 5.0
                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 5.0) {
                    
                    if (![TWTweetComposeViewController canSendTweet]) {
                        UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Sorry, the Twitter function is not available, you may check your setting or network status and try again." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                        [av show];
                        [av release];
                        return;
                    }
                    // Before saving the image, hide toolbar
                    [self hideToolBar];
                    
                    if (UIDeviceOrientationIsLandscape(_currentOrientation)) {
//                        NSLog(@"Device in landscape");
                        //NSLog(@"width: %f, height: %f", sz.width, sz.height);
                        UIGraphicsBeginImageContextWithOptions(CGSizeMake(screenBound.size.height, screenBound.size.width), self.view.opaque, [[UIScreen mainScreen] scale]);
                        [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                        image = UIGraphicsGetImageFromCurrentImageContext();
                        UIGraphicsEndImageContext();
                    } else {
                        UIGraphicsBeginImageContextWithOptions(screenBound.size, self.view.opaque, [[UIScreen mainScreen] scale]);
                        [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
                        image = UIGraphicsGetImageFromCurrentImageContext();
                        UIGraphicsEndImageContext();
                    }
                    
                    // After saving the image, show toolbar
                    [self showToolBar];
                    
                    // twitter
                    TWTweetComposeViewController *twitter = [[TWTweetComposeViewController alloc] init];
                    //                [twitter setInitialText:[NSString stringWithFormat:@"Created with InstaCalendar(%d/%d)", _currentYear, _currentMonth]]; // TODO for release
                    [twitter setInitialText:[NSString stringWithFormat:@"Calendar of %d/%d", _currentYear, _currentMonth]];
                    [twitter addImage:image];
                    twitter.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
                    [self presentModalViewController:twitter animated:YES];
                    
                    __block UIAlertView *twav = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Published to twitter." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                    twitter.completionHandler = ^(TWTweetComposeViewControllerResult result) {
                        switch (result)
                        {
                            case TWTweetComposeViewControllerResultCancelled:
                                // cancel button clicked
                                //[twav setTitle:@"Canceled publishing to twitter."];
                                //[twav show];
                                [twav release];
                                break;
                            case TWTweetComposeViewControllerResultDone:
                                [twav setTitle:@"Published to twitter."];
                                [twav show];
                                [twav release];
                                break;
                            default:
                                [twav release];
                                break;
                        }
                        // maybe a bug, but the line below must be called, 
                        // or any operation is disabled.
                        [self dismissModalViewControllerAnimated:YES];
                    };
                    [twitter release];
                }
                break;
                
            default:
                break;
        }

    }
}


#pragma mark - share - print
- (void)printImage: (UIImage *) image
{
//    NSLog(@"printImage");
    // Obtain the shared UIPrintInteractionController
    UIPrintInteractionController *controller = [UIPrintInteractionController sharedPrintController];
    if(!controller){
//        NSLog(@"Couldn't get shared UIPrintInteractionController!");
        UIAlertView *error = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Couldn't get shared UIPrintInteractionController!"  delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [error show];
        [error release];        
        return;
    }
    
    // We need a completion handler block for printing.
    UIPrintInteractionCompletionHandler completionHandler = ^(UIPrintInteractionController *printController, BOOL completed, NSError *error) {
        if(completed && error)
            NSLog(@"FAILED! due to error in domain %@ with error code %u", error.domain, error.code);
    };
    
    // Obtain a printInfo so that we can set our printing defaults.
    UIPrintInfo *printInfo = [UIPrintInfo printInfo];
    
    // This application prints photos. UIKit will pick a paper size and print
    // quality appropriate for this content type.
    printInfo.outputType = UIPrintInfoOutputPhoto;
    
    // The path to the image may or may not be a good name for our print job
    // but that's all we've got.
    //    printInfo.jobName = [[self.imageURL path] lastPathComponent];
    
    // If we are performing drawing of our image for printing we will print
    // landscape photos in a landscape orientation.
    if(!controller.printingItem && image.size.width > image.size.height)
        printInfo.orientation = UIPrintInfoOrientationLandscape;
    
    // Use this printInfo for this print job.
    controller.printInfo = printInfo;
    
    //  Since the code below relies on printingItem being zero if it hasn't
    //  already been set, this code sets it to nil. 
    controller.printingItem = nil;
    
    
    PrintPageRenderer *ppr = [[PrintPageRenderer alloc] init];
    ppr.imageToPrint = image;
    controller.printPageRenderer = ppr;
    [ppr release];
    
    // The method we use presenting the printing UI depends on the type of 
    // UI idiom that is currently executing. Once we invoke one of these methods
    // to present the printing UI, our application's direct involvement in printing
    // is complete. Our delegate methods (if any) and page renderer methods (if any)
    // are invoked by UIKit.
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
//        NSLog(@"iPad not supported right now");
        //        [controller presentFromBarButtonItem:self.printButton animated:YES completionHandler:completionHandler];  // iPad
    }else {
        [controller presentAnimated:YES completionHandler:completionHandler];  // iPhone
    }
}



#pragma mark - mail
- (void) mailImage:(UIImage *)image
{
    MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
    mailController.mailComposeDelegate = self;
    mailController.toolbar.barStyle = UIBarStyleBlackTranslucent;
    [mailController setSubject:@"Instant Calendar"];
    [mailController setMessageBody:[NSString stringWithFormat:@"Hi, I'd like to share the image calender of (%d/%d) with you:-)", _currentYear, _currentMonth] isHTML:NO];
    [mailController addAttachmentData:UIImagePNGRepresentation(image) mimeType:@"image/png" fileName:[NSString stringWithFormat:@"InstaCalendar_%d_%d.png", _currentYear, _currentMonth]];
    
    [self presentModalViewController:mailController animated:YES];
    [mailController release];
}


#pragma mark - MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
//    NSLog(@"mailComposeController");
    
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Information" message:@"Sending" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    
    switch (result)
    {
        case MFMailComposeResultCancelled:
            break;
        case MFMailComposeResultSaved:
            break;
        case MFMailComposeResultSent:
            message.title = @"Success";
            message.message = @"Mail sent successfully.";
            [message show];
            break;
        case MFMailComposeResultFailed:
            message.title = @"Error";
            message.message = @"Failure, mail not sent.";
            [message show];
            break;
        default:
            break;
    }
    [message release];
    // restore the device orientation
    _currentOrientation = [[UIApplication sharedApplication] statusBarOrientation];
    [self dismissModalViewControllerAnimated:YES];
}

-(void)showToolBar
{
    self.upperToolBar.hidden = FALSE;
    self.lowerToolBar.hidden = FALSE;
//    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationNone];
}

-(void)hideToolBar
{
    self.upperToolBar.hidden = TRUE;
    self.lowerToolBar.hidden = TRUE;
//    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationNone];
}


#pragma mark - UIImageWriteToSavedPhotosAlbum selector method
- (void) savedImage: (UIImage *)image didFinishSavingWithError: (NSError *)error contextInfo: (void *)contextInfo
{
    if (error) {
        UIAlertView *error = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Saving image failed! Make sure there is space for saving images!" delegate:nil cancelButtonTitle:@"Confirm" otherButtonTitles:nil];
        [error show];
        [error release];
    } else {
        UIAlertView *info = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Saved to camera roll." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [info show];
        [info release];
    }
}


// Show the image picker when the user wants to choose an image.
- (void)showImagePicker {
//    NSLog(@"showImagePicker");
    
    // Dismiss any printing popover that might already be showing.
    if([UIPrintInteractionController isPrintingAvailable] && UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        [[UIPrintInteractionController sharedPrintController] dismissAnimated:YES];
    
    
    // UIImagePickerController let's the user choose an image.
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.wantsFullScreenLayout = YES;
    [self presentModalViewController:imagePicker animated:YES];
    [imagePicker release];
}


#pragma mark UIImagePickerController Delegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)info {
    //NSLog(@"OS Version: %@", [[UIDevice currentDevice] systemVersion]);
//    NSLog(@"in imagePickerController:didFinishPickingImage:editingInfo");
    // after choosing pictures, show the preview and action button
    [self.previewButton setEnabled:TRUE];
    [self.actionButton setEnabled:TRUE];
    [self.imageView setImage:image];
    [self dismissModalViewControllerAnimated:YES];
}


@end
