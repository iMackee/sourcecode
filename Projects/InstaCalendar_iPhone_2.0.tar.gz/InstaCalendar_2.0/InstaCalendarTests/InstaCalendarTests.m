//
//  InstaCalendarTests.m
//  InstaCalendarTests
//
//  Created by 何 勇 on 11-11-24.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "InstaCalendarTests.h"

@implementation InstaCalendarTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in InstaCalendarTests");
}

@end
