//
//  InstaCalendarTests.h
//  InstaCalendarTests
//
//  Created by 何 勇 on 11-11-24.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface InstaCalendarTests : SenTestCase

@end
