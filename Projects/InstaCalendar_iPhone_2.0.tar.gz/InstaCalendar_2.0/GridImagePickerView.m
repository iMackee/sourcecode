//  GridImagePickerView.m
//  GalleryCalendar
//
//  Created by User on 11/11/03.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GridImagePickerView.h"
#import "AppDelegate.h"
#import "UIImageExtras.h"
#import "MergeImageViewController.h"

@interface GridImagePickerView (private) 

- (void)initializeGridView;
//- (void)initGridViewPartsWithSize: (NSInteger)size;

// work with MyAssetsLibraryAccessor class
- (void)assetsLibraryDidChanged:(NSNotification *)aNotification;
- (void)assetsURLsDidLoaded:(NSArray *)urls;

@end


#define TOOL_BAR_HEIGHT 44
#define THUMB_WIDTH     72
#define THUMB_HEIGHT    72
#define OFFSET_X        7
#define OFFSET_Y        7
#define CELL_DISTANCE   6
#define GRID_COL_NUM    4
#define MAX_PICKABLE    12

@implementation GridImagePickerView
@synthesize imagesURLs = _imagesURLs;
//@synthesize selectedImage = _selectedImage;
@synthesize delegate=_delegate;
@synthesize scrollView=_scrollView;
@synthesize checkedImages = _checkedImages;
//@synthesize assetsLibrary=_assetsLibrary;
@synthesize chosenDate=_chosenDate;
@synthesize activitIndicator=_activitIndicator;

- (id) init {
	if ((self = [super init])) {
        _checkedImages = [[NSMutableArray alloc] init];
        _myAssetsLibraryAccessor = [[MyAssetsLibraryAccessor alloc] init];
        
        [_myAssetsLibraryAccessor loadURLsWithCBTarget: self
                                           andCBMethod:@selector(assetsURLsDidLoaded:)];
        [_myAssetsLibraryAccessor setDelegate:self]; // initial call back
        
        //[_myAssetsLibraryAccessor enumerationTest];  // test
        self.view.opaque = TRUE;
        self.view.backgroundColor = [UIColor whiteColor];
	}

	return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    /*******
     used for loading static images
    // init view
    [self initializeGridView];
     *******/
    _row = 0;
    _col = 0;
    _counter = 0;
    _pickCounter = 0;
}


/*********************************************
 used for added static images to gird view
// set images to the grid view
- (void)initializeGridView
{
    CGRect mainScreenBounds = [[UIScreen mainScreen] applicationFrame];
    CGRect scrollViewBound = CGRectMake(0, TOOL_BAR_HEIGHT, mainScreenBounds.size.width, mainScreenBounds.size.height-TOOL_BAR_HEIGHT);
    CGRect toolbarFrame = CGRectMake(0, 0, mainScreenBounds.size.width, TOOL_BAR_HEIGHT);
    
    // Tool Bar above scroll view
    UIToolbar *aToolbar = [[[UIToolbar alloc] initWithFrame:toolbarFrame] autorelease];
    aToolbar.barStyle = UIBarStyleBlack;
    self.toolBar = aToolbar;
    [self setupToolbarItems];
	
    // Create scroll view
	scrollView = [[UIScrollView alloc] initWithFrame:scrollViewBound];
	int row = 0;
	int column = 0;
	for(int i = 0; i < _thumbs.count; ++i) {
		
		UIImage *thumb = [_thumbs objectAtIndex:i];
		UIButton * imageButton = [UIButton buttonWithType:UIButtonTypeCustom];
		imageButton.frame = CGRectMake(column*(THUMB_WIDTH+CELL_DISTANCE)+OFFSET_X, row*(THUMB_HEIGHT+CELL_DISTANCE)+OFFSET_Y, THUMB_WIDTH, THUMB_HEIGHT);
		[imageButton setImage:thumb forState:UIControlStateNormal];
		[imageButton addTarget:self action:@selector(imageClicked:) forControlEvents:UIControlEventTouchUpInside];
		imageButton.tag = i; 
		[scrollView addSubview:imageButton];
		
		if (column == GRID_COL_NUM-1) {
			column = 0;
			row++;
		} else {
			column++;
		}
		
	}
	
	[scrollView setContentSize:CGSizeMake(320, (row+1) * 80 + 10)];
	
    [self.view addSubview:toolBar];
    [self.view addSubview:scrollView];
    [toolBar release];
}

- (void)addImage:(UIImage *)image {
    //NSLog(@"addImage");
	[_images addObject:image];
	[_thumbs addObject:[image imageByScalingAndCroppingForSize:CGSizeMake(THUMB_WIDTH, THUMB_HEIGHT)]];
}
 
 end of setting static image to grid view
*********************************************/


// call back method
- (void)assetsURLsDidLoaded:(NSArray *)urls {
    self.imagesURLs = [[[NSMutableArray alloc] initWithArray:urls] autorelease];
    _total = [urls count];
    
    //NSLog(@"assetsURLsDidLoaded, loaded %d items", _total);
    if (_total == 0) {
        CGRect mainScreenBounds = [[UIScreen mainScreen] applicationFrame];
        CGRect toolbarFrame = CGRectMake(0, 0, mainScreenBounds.size.width, TOOL_BAR_HEIGHT);
        
        // Tool Bar above scroll view
        UIToolbar *aToolbar = [[UIToolbar alloc] initWithFrame:toolbarFrame];
        aToolbar.tintColor = [UIColor clearColor];
        aToolbar.barStyle = UIBarStyleBlackTranslucent;
        aToolbar.alpha = 1.0f;
        UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStyleBordered target:self action:@selector(goToMain:)];
        backButton.style = UIBarButtonItemStyleBordered;
        
        UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        
        UIBarButtonItem *info = [[UIBarButtonItem alloc] initWithTitle:@"No images." style:UIBarButtonItemStyleBordered target:nil action:nil];
        info.style = UIBarButtonItemStylePlain;
        aToolbar.items = [NSArray arrayWithObjects: backButton, spaceItem, info, spaceItem, nil];
        
        UILabel *instruct = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 460)];
        instruct.textColor = [UIColor blackColor];
        instruct.lineBreakMode = UILineBreakModeWordWrap;
        instruct.numberOfLines = 0;
        instruct.text = @"To create image calendars:\n   1. Transfer some images to the device. \n   2. InstaCalendar needs location access, go to the Settings app then select Location Service to enable.\n\nWhy do you need location data?\n   The InstaCalendar app itself does not use location data in any way nor does it directly access your GPS device.\n   As you take photos with your iPad / iPhone camera, the GPS data is saved to the file so that other applications(iPhoto, for example) can show where the photo was taken. However, for letting InstaCalendar to create image calendars, Apple requires owners to authorize access to its location services. For more information, we are sorry to ask you to read Apple's Understanding Location Services support article on Apple's support page.";
        instruct.center = self.view.center;
        
        UIScrollView *scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, TOOL_BAR_HEIGHT, 320, 430)];
        scroll.contentSize = CGSizeMake(320, instruct.frame.size.height + 100);
        scroll.showsVerticalScrollIndicator = YES;
        scroll.alwaysBounceVertical = TRUE;
        scroll.userInteractionEnabled = TRUE;
        
        [self.view addSubview:aToolbar];
        [scroll addSubview:instruct];
        [self.view addSubview:scroll];
        
        [scroll release];
        [backButton release];
        [spaceItem release];
        [info release];
        [aToolbar release];
        [instruct release];
    } else {
        ///// init grid view
        CGRect mainScreenBounds = [[UIScreen mainScreen] applicationFrame];
        CGRect scrollViewBound = CGRectMake(0, TOOL_BAR_HEIGHT, mainScreenBounds.size.width, mainScreenBounds.size.height-TOOL_BAR_HEIGHT);
        CGRect toolbarFrame = CGRectMake(0, 0, mainScreenBounds.size.width, TOOL_BAR_HEIGHT);
        
        // Tool Bar above scroll view
        UIToolbar *aToolbar = [[UIToolbar alloc] initWithFrame:toolbarFrame];
        aToolbar.tintColor = [UIColor clearColor];
        aToolbar.barStyle = UIBarStyleBlackTranslucent;
        aToolbar.alpha = 1.0f;
        UIBarButtonItem *nextButton = [[UIBarButtonItem alloc] initWithTitle:@"Next" style:UIBarButtonItemStyleBordered target:self action:@selector(next:)];
        UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancel:)];
        UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        // Title
        UILabel *titleText = [[UILabel alloc] initWithFrame:CGRectMake(0, 9.0f, 200.0f, 21.0f)];
        [titleText setBackgroundColor:[UIColor clearColor]];
        [titleText setFont:[UIFont fontWithName:@"Helvetica-Bold" size:18.0f]];
        [titleText setTextColor:[UIColor whiteColor]];
        [titleText setText:@"pick images"];
        [titleText setTextAlignment:UITextAlignmentCenter];
        UIBarButtonItem *title = [[UIBarButtonItem alloc] initWithCustomView:titleText];
        
        aToolbar.items = [NSArray arrayWithObjects: cancelButton, spaceItem, title, spaceItem, nextButton, nil];
        [self.view addSubview:aToolbar];
        [nextButton release];
        [cancelButton release];
        [spaceItem release];
        [titleText release];
        [title release];
        [aToolbar release];
        
        // Create scroll view
        self.scrollView = [[[UIScrollView alloc] initWithFrame:scrollViewBound] autorelease];
//        [self.scrollView setContentSize:CGSizeMake(mainScreenBounds.size.width, (_total/GRID_COL_NUM+1) * (THUMB_HEIGHT + CELL_DISTANCE) + CELL_DISTANCE)]; // changed to update upon loading process
        [self.view addSubview:self.scrollView];
        
        
        // show an activity indicator before fetching the images from library
        self.activitIndicator = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge] autorelease];
        
        self.activitIndicator.frame = CGRectMake(0, 0, self.activitIndicator.frame.size.width * 2, self.activitIndicator.frame.size.height * 2);
        self.activitIndicator.center = self.view.center;
        self.activitIndicator.backgroundColor = [UIColor colorWithRed:0.1 green:0.1 blue:0.1 alpha:0.5];
        [self.view addSubview:self.activitIndicator];
        //    [self.view bringSubviewToFront:self.activitIndicator];
        [self.activitIndicator startAnimating];
        
        // request thumbnails to fill scroll view
        for (int i = 0; i < _total; i++) {
            NSURL *url = [_imagesURLs objectAtIndex:i];
            // use asychronous method, because the thumbnail can not be get synchronously
            [_myAssetsLibraryAccessor getThumbnailOfAssetsWithCBByURL:url andIndex:i];
        }
    }
}



#pragma mark - MyAssetsLibraryThumbnailDelegate callback
- (void)onGetThumbnail:(UIImage *)thumbnail withIndex:(NSInteger)index
{
    //NSLog(@"onGetThumbnail: %d : %@", index, thumbnail);
    
    UIButton *imageButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    imageButton.frame = CGRectMake(_col*(THUMB_WIDTH+CELL_DISTANCE)+OFFSET_X, _row*(THUMB_HEIGHT+CELL_DISTANCE)+OFFSET_Y, THUMB_WIDTH, THUMB_HEIGHT);
    if (thumbnail) {
        [imageButton setImage:thumbnail forState:UIControlStateNormal];
    } else {
        [imageButton setImage:[UIImage imageNamed:@"icon.png"] forState:UIControlStateNormal];
    }
    
    [imageButton addTarget:self action:@selector(thumbnailClicked:) forControlEvents:UIControlEventTouchUpInside];
    imageButton.tag = index;
    [self.scrollView addSubview:imageButton];
    [self.scrollView setContentSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, (_counter/GRID_COL_NUM+1) * (THUMB_HEIGHT + CELL_DISTANCE) + CELL_DISTANCE)];
    if (_col == GRID_COL_NUM-1) {
        _col = 0;
        _row++;
    } else {
        _col++;
    }

    if (_counter++ + 3 >= _total) {
        [self.activitIndicator removeFromSuperview];
    }
}


////// View
//- (void) initGridViewPartsWithSize: (NSInteger) size
//{
//    CGRect mainScreenBounds = [[UIScreen mainScreen] applicationFrame];
//    CGRect scrollViewBound = CGRectMake(0, TOOL_BAR_HEIGHT, mainScreenBounds.size.width, mainScreenBounds.size.height-TOOL_BAR_HEIGHT);
//    CGRect toolbarFrame = CGRectMake(0, 0, mainScreenBounds.size.width, TOOL_BAR_HEIGHT);
//    
//    // Tool Bar above scroll view
//    UIToolbar *aToolbar = [[UIToolbar alloc] initWithFrame:toolbarFrame];
//    aToolbar.barStyle = UIBarStyleBlackTranslucent;
//    aToolbar.alpha = 0.7f;
//    UIBarButtonItem *finishButton = [[UIBarButtonItem alloc] initWithTitle:@"Finish" style:UIBarButtonItemStyleBordered target:self action:@selector(finish:)];
//    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancel:)];
//    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
//    
//    aToolbar.items = [NSArray arrayWithObjects: cancelButton, spaceItem, finishButton, nil];
//    [self.view addSubview:aToolbar];
//    [finishButton release];
//    [cancelButton release];
//    [spaceItem release];
//    [aToolbar release];
//    
//    // Create scroll view
//	self.scrollView = [[[UIScrollView alloc] initWithFrame:scrollViewBound] autorelease];
//    // added setContentSize to update upon loading process
//    [self.scrollView setContentSize:CGSizeMake(mainScreenBounds.size.width, (size/GRID_COL_NUM+1) * (THUMB_HEIGHT + CELL_DISTANCE) + CELL_DISTANCE)];
//    [self.view addSubview:self.scrollView];
//    
//    NSLog(@"initiate view complete");
//}



// UIAlertView delegate
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex: (NSInteger)buttonIndex
{
    [self dismissModalViewControllerAnimated:YES];
}



// thumb nail click listener with index and URLs
- (void)thumbnailClicked:(id)sender {
    UIButton *button = (UIButton *)sender;
    NSInteger index = button.tag;
    NSURL *clickedURL = [_imagesURLs objectAtIndex:index];
//    NSLog(@"thumbnailClicked: %d, url: %@", index, clickedURL);
    
    if([button.subviews count] > 1) {
        //NSLog(@"subview: %@", [button.subviews objectAtIndex:1]);
        [[button.subviews objectAtIndex:1] removeFromSuperview]; // remove check mark
        
//        NSLog(@"remove from checkedImages in: %d", [self.checkedImages count]);
        for (int i = 0; i < [self.checkedImages count]; i++) {
            NSURL *store = [self.checkedImages objectAtIndex:i];
            NSURL *orig = [self.imagesURLs objectAtIndex:index];
            if(store == orig) {
                [self.checkedImages removeObjectAtIndex:i];
                _pickCounter--;
                break;
            }
        }
//        NSLog(@"remove from checkedImages out: %d", [self.checkedImages count]);
    } else {
        
        // set limitation to max number of 12
        if (_pickCounter >= MAX_PICKABLE) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Information" message:@"Only 12 images (for a whole year) is allowed at a time." delegate:nil cancelButtonTitle:@"Confirm" otherButtonTitles:nil];
            [alert show];
            [alert release];
            return;
        }
        
        // checked mark view
        UIImageView *view = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"checked.png"]];
        view.frame = CGRectMake(0, 0, THUMB_WIDTH/2, THUMB_HEIGHT/2);
        [button addSubview:view];
        [view release];
        _pickCounter++;
        // add chosen images' url for returning
        [self.checkedImages addObject:clickedURL];
    }
    
}


// next button reactor
- (void)next: (id) sender
{
//    NSLog(@"finish clicked");
    
    if([self.checkedImages count] > 0) {
        [self.delegate onPickedImagesURLs:self.checkedImages];
        MergeImageViewController *merge = [[MergeImageViewController alloc] initWithNibName:@"MergeImageViewController" bundle:nil];
        [merge setChosenDate:self.chosenDate];
        [merge setChosenImages:self.checkedImages];
        merge.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentModalViewController:merge animated:YES];
        
        [merge release];

    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Information" message:@"Forget to choose any images?" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
}

- (void) goToMain: (id)sender
{
    [self dismissModalViewControllerAnimated:YES];
}


// cancel button reactor
- (void) cancel: (id) sender
{
//    self.selectedImage = nil;
    [self dismissModalViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
    [self setImagesURLs:nil];
    [self setScrollView:nil];
    [self setCheckedImages:nil];
    [self setChosenDate:nil];
    [self setActivitIndicator:nil];
    [super viewDidUnload];
}

- (void)dealloc {
    [_imagesURLs release];
    [_scrollView release];
    [_checkedImages release];
    [_chosenDate release];
    [_activitIndicator release];
    [_myAssetsLibraryAccessor release];
	[super dealloc];
}

@end
