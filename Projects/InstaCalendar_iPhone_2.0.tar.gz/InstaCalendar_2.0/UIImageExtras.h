//  UIImageExras.h
//  GalleryCalendar
//
//  Created by User on 11/11/03.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


@interface UIImage (Extras)

- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize;

@end
