//
//  ViewController.h
//  InstaCalendar
//
//  Created by 何 勇 on 11-11-24.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>
#import "GridImagePickerView.h"
//#import "GridImagePickerController.h"  //under testing, display problems in iOS 5



@interface ViewController : UIViewController <UINavigationControllerDelegate, UIImagePickerControllerDelegate>
{
    UIBarButtonItem *chooseDateButton;
    UIImageView *mainImageView;
    
    NSMutableArray *_pickedImages;
    UILabel *calendarMainText;
    UIImageView *_calendarImageView;
}

@property (nonatomic, retain) UIImageView *calendarImageView; // calendar view

@property (nonatomic, retain) IBOutlet UIImageView *mainImageView;

- (IBAction)startMerge:(id)sender;
- (IBAction)singleMerge:(id)sender;
- (void)redrawCalendarImageView: (NSDate *)date;

- (void)showAlertWithTitle: (NSString *)title withMessage: (NSString *)msg withButton: (NSString *)btn;

@end
