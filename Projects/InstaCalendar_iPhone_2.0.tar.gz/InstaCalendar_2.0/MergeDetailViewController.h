//
//  MergeDetailViewController.h
//  GalleryCalendar
//
//  Created by User on 11/11/09.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <MessageUI/MessageUI.h>
#import <Twitter/TwRequest.h>
#import <Twitter/TWTweetComposeViewController.h>

@protocol CalendarMergeDelegate <NSObject>

@optional
- (void) onCalendarMergedOfMonth: (NSInteger)month;

@end

@interface MergeDetailViewController : UIViewController <UIActionSheetDelegate, MFMailComposeViewControllerDelegate> 
{
    UIToolbar *_toolBar;
    
    UIImage *_image;
    UIView *_currentCalendarView;
    UIImageView *_currentImageView;
    
    NSInteger _currentYear;
    NSInteger _currentMonth;
    BOOL _toolBarHidden;
    UIInterfaceOrientation _currentOrientation;
    
    CGAffineTransform currentTransform;
    
    id<CalendarMergeDelegate> _delegate;
}

@property (nonatomic, retain) id<CalendarMergeDelegate> delegate;

@property (nonatomic, retain) UIImage *image;

@property (nonatomic, retain) UIView *currentCalendarView;

@property (nonatomic, retain) UIView *currentImageView;
@property (retain, nonatomic) IBOutlet UIView *mergeView;

@property (nonatomic, retain) IBOutlet UIToolbar *toolBar;


- (void)presentImage: (UIImage *)image;
- (void)presentCalendar: (UIView *)calendar;
- (void)setSeletedYear: (NSInteger)year month: (NSInteger)month;

- (IBAction)cancelMerge:(id)sender;
- (IBAction)confirmMerge:(id)sender;
- (IBAction)previewMerge:(id)sender;

@end
