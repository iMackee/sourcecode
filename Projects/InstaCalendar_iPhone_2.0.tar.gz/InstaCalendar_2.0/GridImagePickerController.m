//
//  GridImagePickerController.m
//  GalleryCalendar
//
//  Created by 何 勇 on 11-11-20.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "GridImagePickerController.h"
#import "MergeImageViewController.h"

@interface GridImagePickerController (private)

-(void)loadAssetsGroups;

@end

#define TOOL_BAR_HEIGHT 48
#define THUMB_WIDTH     72
#define THUMB_HEIGHT    72
#define OFFSET_X        7
#define OFFSET_Y        7
#define CELL_DISTANCE   6
#define GRID_COL_NUM    4
#define MAX_PICKABLE    12

@implementation GridImagePickerController
@synthesize toolbar;
@synthesize activityIndicator;
@synthesize tableView;

@synthesize assetsLibrary=_assetsLibrary;
@synthesize groups=_groups;
@synthesize assets=_assets;
@synthesize chosenDate=_chosenDate;
@synthesize sections=_sections;
@synthesize checkedImages=_checkedImages;
@synthesize imagesURLs=_imagesURLs;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self.activityIndicator startAnimating];
    _tagCounter = 0;
    
    self.assets = [[[NSMutableArray alloc] init] autorelease];
    self.sections = [[[NSMutableArray alloc] init] autorelease];
    self.imagesURLs = [[[NSMutableArray alloc] init] autorelease];
    self.checkedImages = [[[NSMutableArray alloc] init] autorelease];
    
    self.groups = [[[NSMutableArray alloc] init] autorelease];
    [self loadAssetsGroups];
    
}

- (void)viewDidUnload
{
    [self setToolbar:nil];
    [self setTableView:nil];
    [self setActivityIndicator:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark UITableViewDelegate methods & UITableViewDatasource methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //NSLog(@"sections: %d", [self.sections count]);
    if ([self.sections count] > 0) {
        return [self.sections count];
    }
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //NSLog(@"number rows:%d", self.groups.count);
    return self.groups.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableArray *sectionItems = (NSMutableArray *)[self.sections objectAtIndex:indexPath.section];
    int numRows = [sectionItems count]/GRID_COL_NUM;
    return (numRows + 1) * (THUMB_HEIGHT + CELL_DISTANCE) + CELL_DISTANCE;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (self.groups.count > 0) {
        ALAssetsGroup *group = (ALAssetsGroup *)[self.groups objectAtIndex:section];
        return [group valueForProperty:ALAssetsGroupPropertyName];
    }
    return @"Camera roll";
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"GridImagePickerController";
    
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        
        int section = indexPath.section;
        //NSLog(@"section: %d", section);
        NSMutableArray *sectionItems = [self.sections objectAtIndex:section];
        
        int n = [sectionItems count];
        //NSLog(@"section items: %d", n);
        int i = 0,rows = 0; 
        
        while(i<n){
            int offset_y = OFFSET_Y + rows*(THUMB_HEIGHT + CELL_DISTANCE);
            int col=0;
            for(col=0; col < GRID_COL_NUM; col++){
                
                if (i>=n) break;
                //            NSURL *url = [self.assets objectAtIndex:i];
                NSURL *url = [sectionItems objectAtIndex:i];
                
                CGRect rect = CGRectMake(OFFSET_X+(THUMB_WIDTH + CELL_DISTANCE)*col, offset_y, THUMB_WIDTH, THUMB_HEIGHT);
                UIButton *thumbBtn=[[UIButton alloc] initWithFrame:rect];
                [thumbBtn setFrame:rect];
                __block UIImage *thumbnail = nil;
                [_assetsLibrary 
                 assetForURL:url  // [self.assets objectAtIndex:indexPath.row]
                 resultBlock:^(ALAsset *asset) {
                     thumbnail = [[UIImage alloc] initWithCGImage:[asset thumbnail]];
                 }
                 failureBlock:^(NSError *error) {
                     NSLog(@"Error happened in accessing assets by url. %@", error); 
                 }];
                
                [thumbBtn setBackgroundImage:thumbnail forState:UIControlStateNormal];
                [thumbBtn setContentMode:UIViewContentModeCenter];
                
                thumbBtn.tag = _tagCounter++;
//                NSLog(@"....tag....%d", thumbBtn.tag);
                
                [thumbBtn addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
                [cell.contentView addSubview:thumbBtn];
                [thumbBtn release];
                i++;
            }
            rows = rows + 1;
        }
    }

    return cell;
}


- (void) buttonPressed: (UIButton *) sender
{
    UIButton *button = (UIButton *)sender;
    NSInteger index = button.tag;
    NSURL *clickedURL = [_imagesURLs objectAtIndex:index];
    //NSLog(@"thumbnailClicked: %d, url: %@", index, clickedURL);
    
    if([button.subviews count] > 1) {
        //NSLog(@"subview: %@", [button.subviews objectAtIndex:1]);
        [[button.subviews objectAtIndex:1] removeFromSuperview]; // remove check mark
        
//        NSLog(@"remove from checkedImages in: %d", [self.checkedImages count]);
        for (int i = 0; i < [self.checkedImages count]; i++) {
            NSURL *store = [self.checkedImages objectAtIndex:i];
            NSURL *orig = [self.imagesURLs objectAtIndex:index];
            if(store == orig) {
                [self.checkedImages removeObjectAtIndex:i];
                _pickCounter--;
                break;
            }
        }
//        NSLog(@"remove from checkedImages out: %d", [self.checkedImages count]);
    } else {
        
        // set limitation to max number of 12
        if (_pickCounter >= MAX_PICKABLE) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Only 12 images (for a whole year) at a time is allowed." delegate:nil cancelButtonTitle:@"Confirm" otherButtonTitles:nil];
            [alert show];
            [alert release];
            return;
        }
        
        // checked mark view
        UIImageView *view = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"checked.png"]];
        view.frame = CGRectMake(0, 0, THUMB_WIDTH/2, THUMB_HEIGHT/2);
        [button addSubview:view];
        [view release];
        _pickCounter++;
        // add chosen images' url for returning
        [self.checkedImages addObject:clickedURL];
    }
}

#pragma mark - 
#pragma mark Assets management
- (void)loadAssetsGroups
{
    if (!self.assetsLibrary) {
        self.assetsLibrary = [[[ALAssetsLibrary alloc] init] autorelease];
    }
    
    ALAssetsGroupEnumerationResultsBlock resultAsset_b =
    ^(ALAsset *asset, NSUInteger index, BOOL *stop) {
        if (!*stop && asset) {
            ALAssetRepresentation *defaultRepresentation = [asset defaultRepresentation];
            [self.imagesURLs addObject:[defaultRepresentation url]];
            [self.assets addObject:[defaultRepresentation url]];
        } else {
//            NSLog(@"%d items found.", [self.assets count]);
            [self.sections addObject:[[[NSMutableArray alloc] initWithArray:self.assets copyItems:YES] autorelease]];
            
            [self.assets removeAllObjects];
        }
    };
    
    ALAssetsLibraryGroupsEnumerationResultsBlock resultBlockGroup =
    ^(ALAssetsGroup *group, BOOL *stop) {
        if (group) {
            [self.groups addObject:group];
            [group setAssetsFilter:[ALAssetsFilter allPhotos]];
            // enumerate a group and add to sections
            [group enumerateAssetsUsingBlock:resultAsset_b];
        } else {
//            NSLog(@"%d groups found.", [self.groups count]);
            [self.tableView reloadData];
            [self.activityIndicator stopAnimating];
            [self.activityIndicator setHidden:YES];
        }
    };
    
    ALAssetsLibraryAccessFailureBlock failureBlock = 
    ^(NSError *error) {
        NSLog(@"exception in enumerating assets. %@", error);
    };

    
    [self.assetsLibrary enumerateGroupsWithTypes:ALAssetsGroupAll usingBlock:resultBlockGroup failureBlock:failureBlock];
}



- (IBAction)cancelButton:(id)sender {
    [self dismissModalViewControllerAnimated:YES];
}

- (IBAction)nextButton:(id)sender {
//    NSLog(@"next clicked");
    
    if([self.checkedImages count] > 0) {
//        [self.delegate onPickedImagesURLs:self.checkedImages];
        MergeImageViewController *merge = [[MergeImageViewController alloc] initWithNibName:@"MergeImageViewController" bundle:nil];
        [merge setChosenDate:self.chosenDate];
        [merge setChosenImages:self.checkedImages];
        merge.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentModalViewController:merge animated:YES];
        
        [merge release];
        
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Forget to choose any images?" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        [alert release];
    }

}
- (void)dealloc {
    [_assetsLibrary release];
    [_groups release];
    [_assets release];
    [_sections release];
    [_checkedImages release];
    [_imagesURLs release];

    [toolbar release];
    [tableView release];
    [activityIndicator release];
    
    [super dealloc];
}
@end
