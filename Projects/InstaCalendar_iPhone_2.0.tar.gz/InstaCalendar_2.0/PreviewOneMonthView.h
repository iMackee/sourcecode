//
//  PreviewOneMonthView.h
//  InstaCalendar
//
//  Created by 何 勇 on 11-12-2.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CalendarImageView.h"
#import "PrintPageRenderer.h"
#import <MessageUI/MessageUI.h>
#import <Twitter/TwRequest.h>
#import <Twitter/TWTweetComposeViewController.h>

@interface PreviewOneMonthView : UIViewController <UIActionSheetDelegate, MFMailComposeViewControllerDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate>
{
//    UIImage *_currImage;
    UIView *_currentCalendarView;
    
    NSInteger _currentMonth;
    NSInteger _currentYear;
    BOOL _toolBarHidden;
    UIInterfaceOrientation _currentOrientation;
    CGAffineTransform currentTransform;
    CGAffineTransform savedCalTransform;
    CGPoint savedCalCenter;
}
//@property (retain, nonatomic) UIImage *currImage;
@property (nonatomic, retain) UIView *currentCalendarView;

@property (retain, nonatomic) IBOutlet UIToolbar *upperToolBar;
@property (retain, nonatomic) IBOutlet UIToolbar *lowerToolBar;
@property (retain, nonatomic) IBOutlet UIBarButtonItem *dateText;
@property (retain, nonatomic) IBOutlet UIBarButtonItem *previewButton;
@property (retain, nonatomic) IBOutlet UIBarButtonItem *actionButton;
@property (retain, nonatomic) IBOutlet UIImageView *imageView;
@property (retain, nonatomic) IBOutlet UIView *mainView;
- (IBAction)nextMonth:(id)sender;
- (IBAction)prevMonth:(id)sender;
- (IBAction)done:(id)sender;
- (IBAction)preview:(id)sender;
- (IBAction)action:(id)sender;
- (IBAction)pickImage:(id)sender;

//- (void) setImage: (UIImage *) image;
@end
